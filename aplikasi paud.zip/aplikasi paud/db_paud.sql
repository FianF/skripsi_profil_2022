-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 29 Nov 2022 pada 09.05
-- Versi server: 10.1.39-MariaDB
-- Versi PHP: 7.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_paud`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_berita`
--

CREATE TABLE `tb_berita` (
  `id_berita` int(15) NOT NULL,
  `judul` text NOT NULL,
  `isi` text NOT NULL,
  `foto` text NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_berita`
--

INSERT INTO `tb_berita` (`id_berita`, `judul`, `isi`, `foto`, `tanggal`) VALUES
(6, 'RUU SISDIKNAS', 'Terdapat kabar baik untuk guru PAUD, TK, SD, SMP, SMA, maupun Madrasah yang disampaikan langsung oleh Nadiem Makarim, Menteri Pendidikan.Terkait kabar baik untuk guru semua jenjang pendidikan dari PAUD hingga SMA berkaitan dengan kebijakan pendidikan. Seperti diketahui oleh guru-guru, bahwa saat ini telah ada tiga Undang-undang Pendidikan yang berlaku secara umum, yakni Undang-undang Sisdiknas, Undang-undang Dikti, dan juga Undang-undang Guru dan Dosen nomor 14 tahun 2005. Saat ini Kemdikbud Ristek tengah menyusun RUU Sisdiknas baru yang terintegrasi dan holistik.Dari RUU Sisdiknas ini, nantinya ketiga UU tersebut sudah tidak ada lagi, dan hanya ada UU Sisdiknas yang baru.Undang-undang yang paling mendekati secara umum yaitu UU nomor 14 tahun 2005 tentang guru dan dosen.Sebab salah satu poin yang paling penting dari Undang-undang tersebut adalah mengenai tunjangan profesi guru atau TPG.Berkaitan dengan itu, guru-guru perlu mengetahui terkait ', 'q4ucy7bz02v3onswj1ihlxg9rkfdtpa6em58.jpeg', '2022-09-26'),
(7, 'Penghargaan Bunda Paud.', 'Bunda PAUD Kabupaten Batu Bara, Maya Indriasari Zahir didampingi Ketua Kelompok Kerja Bunda Pendidikan Anak Usia Dini Kabupaten Batu Bara, Erlina Yusuf menerima secara langsung penghargaan Apresiasi Bunda PAUD Tingkat Nasional dari Kementerian Pendidikan Kebudayaan Riset dan Teknologi.\r\nPenghargaan Apresiasi Bunda PAUD Tingkat Nasional untuk ibu Bupati Kabupaten Batu Bara selaku Bunda PAUD diserahkan Ketua Kelompok Kerja Regulasi dan Tata Kelola Satuan Pendidikan Anak Usia Dini Kemendikbudristek, Muhammad Ngasmawi ditengah kunjungan kerja Bunda PAUD Kabupaten Batu Bara ke Direktorat PAUD Kemendikbudristek di Gedung  E Lantai 7 Senayan, Jakarta Pusat, Rabu (21/9).\"Mewakili ibu Plt Direktur PAUD, kami menyampaikan selamat kepada Bunda PAUD Kabupaten Batu Bara atas prestasi yang telah diraih dalam ajang Apresiasi Bunda PAUD Tingkat Nasional Tahun 2021. Semoga melalui pemberian penghargaan ini menjadi penambah semangat, motivasi serta kinerja Bunda PAUD dan Pokja Bunda PAUD untuk menghadirkan PAUD Berkualitas, terjangkau dan meningkatkan Angka Partisipasi Kasar (APK) PAUD di daerahnya,\" ujar Muhammad Ngasmawi.Sesuai dengan kriteria dan tahapan di atas, Apresiasi Bunda PAUD Tingkat Nasional  telah menghasilkan 15 Bunda PAUD Provinsi, 40 Bunda PAUD Kab/Kota, 13 Bunda PAUD Kecamatan, dan 11 Bunda PAUD Desa/Kelurahan Tingkat Nasional. Hanya saja, mengingat adanya penghematan belanja anggaran negara, kegiatan Puncak Acara Pemberian Anugerah Apresiasi Bunda PAUD Tingkat Nasional tidak dapat dilaksanakan ', '6qhrzjs7e0yvibck4txougf8d1lm32aw59pn.png', '2022-09-26'),
(8, 'asap', 'Tuntutan masyarkat terhadap mutu pelayanan pendidikan dari waktu ke waktu makin tinggi. Seiring dengan perkembangan ilmu dan teknologi yang semaik pesat , maka lembaga pendidikan dalam berbagai tingka dan jenjang pendidikan tidak lagi dapat berpangku tangan untuk melestarikan kemampuan budaya dan performa suatu sekolah namun harus gigih melakukan inovasi perubahan dalam berbagai aspek agar tidak ditinggalkan oleh masyarakat yang hidup dalam era globalisasi.\r\nMenyadari hal tersebut, sekolah sebagai agen perubahan di masyarakat harus senantiasa melakukan perubahan sesuai dengan derap dinamika perkembangan masyarakat dalam perkembangan IPTEK. Teknologi informasi berbasis komputer adalah salah satu media yang cukup efektif dalam mengelola sistem informasi sekolah. Penggunaan internet juga mulai meningkat di kalangan pendidikan terutama pada masa pandemi covid 19 ini. Penggunaan tidak hanya sekedar mencari informasi di internet saja, tetapi jug sudah menerapkan teknologi internet ini sebagai media publikasi sekolah dan media pembelajaran dalam meningkatkan mutu sekolah.\r\nSalah satu upaya yang bisa dijadikan sebagai program unggulan best practice sebuah institusi pendidikan sekolah adalah pembuatan website sekolah dengan domain sch.id yang dipandang sebagai jembatan emas untuk meraih masa depan yang gemilang, terlebih didalam website ini terdapat sistem yang memungkinkan pendaftaran siswa baru dan berbagai informasi sekolah yang menjadi daya tarik masyarakat dalam memandang citra sekolah.untuk itu sudah selayaknya lembaga pendidikan memiliki website sebagai sarana komunikasi antara guru, siswa dan wali murid.  \r\n', '6mcs7x5z1w4fvoth2bg3iyedn8qpkjarl90u.jpeg', '2022-10-03'),
(9, 'am', 'Tuntutan masyarkat terhadap mutu pelayanan pendidikan dari waktu ke waktu makin tinggi. Seiring dengan perkembangan ilmu dan teknologi yang semaik pesat , maka lembaga pendidikan dalam berbagai tingka dan jenjang pendidikan tidak lagi dapat berpangku tangan untuk melestarikan kemampuan budaya dan performa suatu sekolah namun harus gigih melakukan inovasi perubahan dalam berbagai aspek agar tidak ditinggalkan oleh masyarakat yang hidup dalam era globalisasi.\r\nMenyadari hal tersebut, sekolah sebagai agen perubahan di masyarakat harus senantiasa melakukan perubahan sesuai dengan derap dinamika perkembangan masyarakat dalam perkembangan IPTEK. Teknologi informasi berbasis komputer adalah salah satu media yang cukup efektif dalam mengelola sistem informasi sekolah. Penggunaan internet juga mulai meningkat di kalangan pendidikan terutama pada masa pandemi covid 19 ini. Penggunaan tidak hanya sekedar mencari informasi di internet saja, tetapi jug sudah menerapkan teknologi internet ini sebagai media publikasi sekolah dan media pembelajaran dalam meningkatkan mutu sekolah.\r\nSalah satu upaya yang bisa dijadikan sebagai program unggulan best practice sebuah institusi pendidikan sekolah adalah pembuatan website sekolah dengan domain sch.id yang dipandang sebagai jembatan emas untuk meraih masa depan yang gemilang, terlebih didalam website ini terdapat sistem yang memungkinkan pendaftaran siswa baru dan berbagai informasi sekolah yang menjadi daya tarik masyarakat dalam memandang citra sekolah.untuk itu sudah selayaknya lembaga pendidikan memiliki website sebagai sarana komunikasi antara guru, siswa dan wali murid.  \r\nPembelajaran adalah suatu proses penciptaan lingkungan yang memungkinkan terjadinya proses belajar. Belajar dalam pengertian aktivitas dari peserta didik dalam berinteraksi dengan lingkungan yang menghasilkan perubahan perilaku yang bersifat relatif konstan. Dalam rangka menciptakan model-model pembelajaran yang inovatif, maka pembelajaran dan promosi sekolah. Setiap tenaga pendidik dan tenaga kependidikan di hampir semua jenjang pendidikan diwajibkan untuk melek teknologi informasi. tenaga pendidik pada semua jenjang pendidikan didorong untuk meningkatkan kemampuan terutama kemampuan dalam mengoperasikan aplikasi berbasis web serta bagaimana membuat web sekolah. Aplikasi berbasis web ini dapat dibuat dengan fitur-fitur seperti membuat profil sekolah, profil guru, profil tenaga kependidikan dan profil siswa serta dapat ditambahkan fitur pendaftara siswa secara online. Aplikasi berbasis web sendiri juga dapat digunakan dalam menunjang proses belajar mengajar misalnya dengan membangun e-learning. Selain untuk menunjang kegiatan pendidikan, melek teknologi informasi juga menunjang guru dalam menyelesaikan persoalan administrasi. Teknologi informasi tidak hanya dibutuhkan pada jenjang pendidikan yang tinggi, namun juga dalam jenjang pendidikan Sekolah Dasar bahkan Pendidikan Anak Usia Dini (PAUD). Kebutuhan administratif adalah hal mutlak dalam sekolah agar tercipta manajemen yang tertata rapi dan meningkatkan kualitas pelayanan itu sendiri.\r\nDengan mempelajari perkembangan ilmu teknologi informasi sangat berperan dalam  belajar untuk meningkatkan kecerdasan linguistik (kecerdasan kata-kata), logika matematika (kecerdasan nomor dan sebab akibat spasial), kecerdasan image dan gambar-gambar musikal (kecerdasan tone, thythim), dan interpersonal (kecerdasan memahami diri sendiri. Keberhasilan peningkatan mutu sumber daya manusia melalui pendidikan terkait dengan berbagai aspek, salah satunya adalah SDM tenaga pendidik yang mampu medesain pembelajaran dan mampu menggunakan serta membuat media pembelajaran yang menarik, dari sisi manajemen, sekolah akan dikenal oleh masyarakat apa bila publikasi atau promosi sekolah dilakukan dengan cara, efisien, efektif, dan menarik. \r\nSelama ini Pemberitahuan tentang informasi sekolah PAUD Mawarsari 6 masih dilakukan secara manual, kebanyakan informasi terbaru masih ditempel dipapan pengumuman, melalui speaker yang dipasang di kelas, melalui mulut ke mulut, surat selebaran yang dibagikan kepada siswa dan masih menggunakan media informasi seperti sepanduk dan pamflet sebagai media promosi kepada publik. \r\nDengan berkembangnya teknologi informasi dan internet maka penerapan website ini diharapkan dapat membantu pihak sekolah PAUD Mawarsari 6 dalam menyampaikan berbagai informasi kepada Guru, Karyawan, Siswa dan Masyarakat Umum sehingga informasi tidak hanya menjangkau lingkungan Desa bojongsoang saja tetapi lebih meluas ke wilayah sekitarnya. Ide dasar pembuatan website ini adalah beberapa sekolah negeri maupun  sekolah swasta sekarang sudah memiliki website untuk menyajikan berbagai informasi sekolah, begitu juga untuk Universitas telah sukses memberikan berbagai informasi melalui website\r\nPOS PAUD Mawarsari 6 yang dikelola oleh ibu Nia Siti Kusniawati S.Pd beralamat di Jalan Cikoneng RT/RW 01/06 Desa/Kelurahan Bojongsoang Kecamatan Bojongsoang. Dengan Akte Notaris Pendirian Organisasi/Yayasan dan Pengesahan Mahkumham Pendirian Lembaga PAUD yaitu Yayasan Bojongsoang Baru, Nama Ketua Yayasan/Penyelenggara Ati Nurani, S.E,  Dikeluarkan Oleh	Robby Rodlya, S.H., M.Kn, Nomor Akte Notaris 04,  Tanggal/Bulan/Tahun 25 Januari 2016,  No. Kemenhumham AHU-000-4517. AH.01.04, Tanggal/Bulan/Tahun	26 Januari 2016. Berikut  Data Pendidik, Tenaga Kependidikan, Peserta Didik :\r\n', '013l7cd2t4fxnyhizbuwjoqkm9ars5ev86gp.jpeg', '2022-10-03');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_fasilitas`
--

CREATE TABLE `tb_fasilitas` (
  `id_fasilitas` int(15) NOT NULL,
  `foto` text NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_fasilitas`
--

INSERT INTO `tb_fasilitas` (`id_fasilitas`, `foto`, `deskripsi`) VALUES
(1, '568ci3rlso97tpqdzawxk4mnf0uj2evhbgy1.jpeg', 'Tempat Bermain'),
(2, '45k3dmnxbr8yjpfev97owcu0l6z1htiaqsg2.jpeg', 'Tempat Bermain'),
(3, 'd5jc1m3qbwn8xsgfezy264piu79ra0vhlokt.jpeg', 'Ruang Belajar'),
(4, 'ewy7si0r5vjg9qnfz6u82amlb3pt4hx1cdko.jpeg', 'Raung Belajar');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_galeri`
--

CREATE TABLE `tb_galeri` (
  `id_galeri` int(15) NOT NULL,
  `gambar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_galeri`
--

INSERT INTO `tb_galeri` (`id_galeri`, `gambar`) VALUES
(15, 'rd579lzp28ij4ycsu1ko0x3tabweqghvfn6m.jpg'),
(16, 'a1vb2qhcxj5n63em48iplz7s90fuodktwrgy.jpeg'),
(17, '0mhsz8v2dculix5kbngta349jwrpf6eyo7q1.jpeg'),
(18, 'mtha71pjkv8nx2byr59s60cwdgo4f3zqluie.jpeg'),
(19, 'b9zpmlqdfk7438xc6jihynsewo1va0g2rtu5.jpeg'),
(20, 'd5clmo6fbwk2a0z7h4evqnti91yj3p8usgxr.jpeg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_guru`
--

CREATE TABLE `tb_guru` (
  `id_guru` int(15) NOT NULL,
  `nama` text NOT NULL,
  `alamat` text NOT NULL,
  `telp` text NOT NULL,
  `foto_guru` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_guru`
--

INSERT INTO `tb_guru` (`id_guru`, `nama`, `alamat`, `telp`, `foto_guru`) VALUES
(1, 'Della Maesti Nurhasanah, S.Pd', 'Bojongsoang', '085654788321', '69iqevw5cdo1tmn7fxu2pj4bzrh8ysk03gal.png'),
(2, 'Nurhasanah', 'Bojongsoang', '081722658932', 'gxquk10d5js764p29ncbvte8hywlf3ramoiz.png'),
(3, 'Masruroh, S.Pd.I', 'Bojongsoang', '081212345987', 'wpgchd3n6lkvbe7zo5aufq1xj2mi9tyrs804.png'),
(4, 'Lisna Nur Dina Yanti, S.Pd', 'Bojongsoang', '081932659999', 'qpn3scj40ix57atrhfbzouydvk2ml9we6g81.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_login`
--

CREATE TABLE `tb_login` (
  `id_login` int(15) NOT NULL,
  `username` text NOT NULL,
  `telp` text NOT NULL,
  `status` text NOT NULL,
  `password` text NOT NULL,
  `password2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_login`
--

INSERT INTO `tb_login` (`id_login`, `username`, `telp`, `status`, `password`, `password2`) VALUES
(1, 'admin', '086253425388', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin'),
(3, 'user', '096765343234', 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 'user'),
(4, 'atep', '086253425387', 'admin', 'cd47220ebeee5ab292fb0b28eb2fa99d', 'atep'),
(5, 'ade', '1', 'user', 'c4ca4238a0b923820dcc509a6f75849b', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pendaftaran`
--

CREATE TABLE `tb_pendaftaran` (
  `id_pendaftaran` int(15) NOT NULL,
  `nama` text NOT NULL,
  `jk` text NOT NULL,
  `ttl` text NOT NULL,
  `alamat` text NOT NULL,
  `agama` text NOT NULL,
  `ortu` text NOT NULL,
  `telp` text NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pendaftaran`
--

INSERT INTO `tb_pendaftaran` (`id_pendaftaran`, `nama`, `jk`, `ttl`, `alamat`, `agama`, `ortu`, `telp`, `tanggal`) VALUES
(1, 'Cecep', 'Laki-laki', 'Garut, 12 Januari 2021', 'Baleendah', 'Islam', 'Dadang', '085432425364', '2022-08-28'),
(2, 'Ujang Deden', 'Laki-laki', 'Garut, 12 Januari 2019', 'Banjaran', 'Islam', 'Dadang', '0865476177', '2022-09-10'),
(3, 'atep ', 'Laki-laki', 'Talegong, 17 - 05 - 1998', 'talegong', 'islam', 'papah', '123456789', '2022-09-15');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pengumuman`
--

CREATE TABLE `tb_pengumuman` (
  `id_pengumuman` int(15) NOT NULL,
  `judul` text NOT NULL,
  `isi` text NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pengumuman`
--

INSERT INTO `tb_pengumuman` (`id_pengumuman`, `judul`, `isi`, `tanggal`) VALUES
(2, 'libur', 'Akan ada hari libur', '2022-08-27'),
(3, 'Libur Natal', 'Pada hari ini sekolah libur dikarenakan bertepatan dengan hari natal', '2022-09-26'),
(4, 'Libur', 'Hari ini kegiatan Belajar mengajar libur karena bertepatan dengan hari cuti bersama', '2022-09-26');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_profil`
--

CREATE TABLE `tb_profil` (
  `id_profil` int(15) NOT NULL,
  `judul` text NOT NULL,
  `isi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_profil`
--

INSERT INTO `tb_profil` (`id_profil`, `judul`, `isi`) VALUES
(1, 'tentang kami', 'POS PAUD Mawarsari 6 yang dikelola oleh ibu Nia Siti Kusniawati S.Pd beralamat di Jalan Cikoneng RT/RW 01/06 Desa/Kelurahan Bojongsoang Kecamatan Bojongsoang. Dengan Akte Notaris Pendirian Organisasi/Yayasan dan Pengesahan Mahkumham Pendirian Lembaga PAUD yaitu Yayasan Bojongsoang Baru, Nama Ketua Yayasan/Penyelenggara Ati Nurani, S.E,  Dikeluarkan Oleh	Robby Rodlya, S.H., M.Kn, Nomor Akte Notaris 04,  Tanggal/Bulan/Tahun 25 Januari 2016,  No. Kemenhumham AHU-000-4517. AH.01.04, Tanggal/Bulan/Tahun	26 Januari 2016. Berikut  Data Pendidik, Tenaga Kependidikan, Peserta Didik '),
(2, 'visi', 'Terwujudnya anak-anak yang cerdas, sehat, ceria dan berahlak mulia serta bertaqwa dengan berwawasan lingkungan'),
(3, 'misi', 'Memberikan pengasuhan dan pelayanan bagi anak usia dini. Membentuk karakter dan berkepribadian serta mandiri. Memahami diri sendiri, orang lain dan lingkungannya. Meningkatkan kesadaran dan partisiipasi masyarakat dalam pelayanan PAUD. Memberikan pelayanan holistik integratif posyandu dengan memperhatikan esensial kebutuhan anak usia dini.'),
(4, 'wa', '0865476177'),
(5, 'email', 'paud@example.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_siswa`
--

CREATE TABLE `tb_siswa` (
  `id_siswa` int(15) NOT NULL,
  `nama` text NOT NULL,
  `jk` text NOT NULL,
  `alamat` text NOT NULL,
  `kelas` text NOT NULL,
  `foto` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_siswa`
--

INSERT INTO `tb_siswa` (`id_siswa`, `nama`, `jk`, `alamat`, `kelas`, `foto`) VALUES
(1, 'Udin', '', 'Bojongsoang', 'A', 'ajg4p7bv3fh562z91nkmrsutwde0x8oyqcil.png'),
(2, 'Emen', '', 'Bojongsoang', 'A', '8oh0gw5p3qsdfuazmlx6t4rk29bjv17ieync.png'),
(3, 'Odik', '', 'Bojongsoang', 'A', 'us2rnjf1640hq3ayv5c8zmt7gwdloxkbpei9.png'),
(4, 'asep', '', 'Bojongsoang', 'C', 'y25f8jgl1xn90i6vz7reobq3cu4watpsdmkh.png'),
(5, 'andre', '', 'Bojongsoang', 'C', '5yrmjqkfa9d1slx3h4gne6o02iwc8t7zvubp.png'),
(6, 'aas', '', 'bojongsoang', 'A', 'pa479ywx3sqbntrec0h5zv8k6uo1g2fldjim.png'),
(7, 'adang', '', 'Bojongsoang', 'C', '5fxil83bctug9sn74zva26epkjrywqmd1o0h.png'),
(8, 'adeng', '', 'Bojongsoang', 'C', 'b4hyi6q5luw3xrvjok79dnmcstapf08z2e1g.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_struktur`
--

CREATE TABLE `tb_struktur` (
  `id_struktur` int(15) NOT NULL,
  `nama` text NOT NULL,
  `jabatan` text NOT NULL,
  `foto` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_struktur`
--

INSERT INTO `tb_struktur` (`id_struktur`, `nama`, `jabatan`, `foto`) VALUES
(1, 'Nia Siti Kusniawati, S.Pd.', 'Ketua Pengelola', '9y01csmi6uapfw4b8volh3tn52dj7qxkergz.png'),
(2, 'Masruroh, S.Pd.I', 'Sekretaris', 'u4k0siohc1r6d8gav3twl72fb5myxeqpzjn9.png'),
(3, 'Lisna Nur Dina Yanti, S.Pd.', 'Bendahara', 'yabqo5iecg4vn9hfpktsl0mzjw3xu21r8d67.png'),
(4, 'Syalma Fujiyanti', 'Tenaga Administrasi', 'c7pv2mkun1g95zfx63htdorq8jiblwesay04.png'),
(5, 'Della Maesti Nurhasanah, S.Pd', 'Guru', 'tm523b0zn18sulciy7j9xo4ewkgr6qvadfph.png'),
(6, 'Nurhasanah', 'Guru', 'i1q2xkv4shtw7la0pz6f9eocun3d58grjmby.png'),
(7, 'Masruroh, S.Pd.i', 'Guru', 'ib3zf4ypq5v7tm6sw2hn0xjlc8rukeao91dg.png'),
(8, 'Lisna Nur Dina Yanti, S.Pd', 'Guru', 'zusg6n2mdhq3ke1j5icb0owxylv7r8tfa9p4.png');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_berita`
--
ALTER TABLE `tb_berita`
  ADD PRIMARY KEY (`id_berita`);

--
-- Indeks untuk tabel `tb_fasilitas`
--
ALTER TABLE `tb_fasilitas`
  ADD PRIMARY KEY (`id_fasilitas`);

--
-- Indeks untuk tabel `tb_galeri`
--
ALTER TABLE `tb_galeri`
  ADD PRIMARY KEY (`id_galeri`);

--
-- Indeks untuk tabel `tb_guru`
--
ALTER TABLE `tb_guru`
  ADD PRIMARY KEY (`id_guru`);

--
-- Indeks untuk tabel `tb_login`
--
ALTER TABLE `tb_login`
  ADD PRIMARY KEY (`id_login`);

--
-- Indeks untuk tabel `tb_pendaftaran`
--
ALTER TABLE `tb_pendaftaran`
  ADD PRIMARY KEY (`id_pendaftaran`);

--
-- Indeks untuk tabel `tb_pengumuman`
--
ALTER TABLE `tb_pengumuman`
  ADD PRIMARY KEY (`id_pengumuman`);

--
-- Indeks untuk tabel `tb_profil`
--
ALTER TABLE `tb_profil`
  ADD PRIMARY KEY (`id_profil`);

--
-- Indeks untuk tabel `tb_siswa`
--
ALTER TABLE `tb_siswa`
  ADD PRIMARY KEY (`id_siswa`);

--
-- Indeks untuk tabel `tb_struktur`
--
ALTER TABLE `tb_struktur`
  ADD PRIMARY KEY (`id_struktur`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_berita`
--
ALTER TABLE `tb_berita`
  MODIFY `id_berita` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `tb_fasilitas`
--
ALTER TABLE `tb_fasilitas`
  MODIFY `id_fasilitas` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `tb_galeri`
--
ALTER TABLE `tb_galeri`
  MODIFY `id_galeri` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `tb_guru`
--
ALTER TABLE `tb_guru`
  MODIFY `id_guru` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `tb_login`
--
ALTER TABLE `tb_login`
  MODIFY `id_login` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `tb_pendaftaran`
--
ALTER TABLE `tb_pendaftaran`
  MODIFY `id_pendaftaran` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tb_pengumuman`
--
ALTER TABLE `tb_pengumuman`
  MODIFY `id_pengumuman` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `tb_profil`
--
ALTER TABLE `tb_profil`
  MODIFY `id_profil` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `tb_siswa`
--
ALTER TABLE `tb_siswa`
  MODIFY `id_siswa` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `tb_struktur`
--
ALTER TABLE `tb_struktur`
  MODIFY `id_struktur` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
