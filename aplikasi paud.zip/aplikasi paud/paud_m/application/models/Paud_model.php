<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Paud_model extends CI_Model
{
    public function bacaData($table)
    {
        return $this->db->get($table);
    }

    function hapusData($table, $field, $id)
    {
        return $this->db->where($field, $id)->delete($table);
    }

    function simpanData($table, $data)
    {
        return $this->db->insert($table, $data);
    }
    function editData($table, $id_table, $id)
    {
        return $this->db->where($id_table, $id)->get($table)->row_array();
    }
    function updateData($table, $data, $field, $id)
    {
        return $this->db->where($field, $id)->update($table, $data);
    }
    function cekLogin($username, $pass)
    {
        return $this->db->get_where('tb_login', array('username' => $username, 'password' => $pass))->row_array();
    }

    function cetakKelas($kelas)
    {
        $this->db->select('*')->from('tb_siswa');
        if ($kelas) {
            $this->db->where('kelas', $kelas);
        }
        return $this->db->get()->result();
    }
    function cetakPendaftaran($mulai, $selesai)
    {
        $this->db->select('*')->from('tb_pendaftaran');
        if ($mulai && $selesai) {
            $this->db->where('tanggal >=', $mulai)->where('tanggal <=', $selesai);
        } else if ($mulai) {
            $this->db->where('tanggal >=', $mulai);
        } else if ($selesai) {
            $this->db->where('tanggal <=', $selesai);
        }
        return $this->db->get()->result();
    }
}

/* End of file Perpus_model.php */
/* Location: ./application/models/Perpus_model.php */