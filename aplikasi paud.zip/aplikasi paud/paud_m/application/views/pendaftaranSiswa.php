<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendaftaran siswa</title>
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/unicat/styles/bootstrap4/bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">
</head>

<body class="bg-mantap">
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-md-8">
                <?php $data = $this->session->flashdata('pesan');
                if ($data) { ?>
                    <div class="alert <?= $data[0] ?> alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <i class="fa <?= $data[2] ?>" aria-hidden="true"></i> <?= $data[1] ?>
                    </div>
                <?php } ?>
                <div class="card card-login">
                    <div class="card-header mb-0">
                        <table>
                            <tr>
                                <td>
                                    <img class="profile-img rounded-circle" src="<?= base_url('assets/img/sekolah/logo.png'); ?>" alt="logo-sekolah">
                                </td>
                                <td>
                                    <h5 class="text-center" style="padding-left: 70px;">FORM PENDAFTARAN PAUD MAWARSARI 6</h5>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo base_url('admin/Pendaftaran/daftarUser'); ?>" method="post">
                            <div class="form-group">
                                <label for="">Nama</label>
                                <input type="text" name="nama" class="form-control" autofocus required>
                            </div>
                            <div class="form-group">
                                <label for="jk">Jenis kelamin</label>
                                <select name="jk" id="jk" class="form-control">
                                    <option value="Laki-laki">Laki-laki</option>
                                    <option value="Perempuan">Perempuan</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="">Tempat, tanggal lahir</label>
                                <input type="text" name="ttl" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="">Alamat</label>
                                <input type="text" name="alamat" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="">Agama</label>
                                <input type="text" name="agama" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="">Orang tua/wali</label>
                                <input type="text" name="ortu" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="">Telepon/WA</label>
                                <input type="text" name="telp" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <input type="submit" name="" value="Daftar" class="btn btn-primary btn-block">
                            </div>
                            <div class="form-group">
                                <input type="reset" name="" value="Reset" class="btn btn-secondary btn-block">
                            </div>
                        </form>
                    </div>
                    <div class="card-footer">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?= base_url() ?>assets/unicat/js/jquery-3.2.1.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/styles/bootstrap4/popper.js"></script>
    <script src="<?= base_url() ?>assets/unicat/styles/bootstrap4/bootstrap.min.js"></script>
</body>

</html>