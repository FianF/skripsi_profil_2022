<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/unicat/styles/bootstrap4/bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">
</head>

<body class="bg-mantap">
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-md-4">
                <div class="card card-login">
                    <div class="card-header mb-0">
                        <img class="profile-img rounded-circle" src="<?= base_url('assets/img/sekolah/logo.png'); ?>" alt="logo-sekolah">
                        <h5 class="text-center">Please <span class="font-weight-bold text-primary">LOGIN</span></h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo base_url('Home/prosesLogin'); ?>" method="post">
                            <div class="form-group">
                                <label for="">Username</label>
                                <input type="text" name="username" class="form-control" autofocus required placeholder="Username">
                            </div>
                            <label for="">Password</label>
                            <div class="form-group">
                                <input type="password" name="password" class="form-control" required placeholder="Password">
                            </div>
                            <div class="form-group">
                                <input type="submit" name="" value="Login" class="btn btn-primary btn-block">
                            </div>
                        </form>
                    </div>
                    <div class="card-footer">
                        <label for=""> Belum punya akun ? </label>
                        <a href="<?php echo base_url('Home/reg'); ?>" class="pull-right need-help">daftar disini </a><span class="clearfix"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?= base_url() ?>assets/unicat/js/jquery-3.2.1.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/styles/bootstrap4/popper.js"></script>
    <script src="<?= base_url() ?>assets/unicat/styles/bootstrap4/bootstrap.min.js"></script>
</body>

</html>