<style>
    p {
        color: black;
        margin: 0;
    }
</style>

<div class="courses">
    <div class="section_background parallax-window" data-parallax="scroll" data-image-src="<?= base_url() ?>assets/unicat/images/courses_background.jpg" data-speed="0.8"></div>
    <div class="container">
        <div class="row courses_row">

            <!-- Course -->
            <div class="col-lg-12 course_col">
                <center>
                    <img style="height: 300px;" src="<?= base_url('assets/img/berita/' . $berita['foto']); ?>" alt="logo-sekolah">
                </center>

                <div class="card">
                    <div class="card-header">
                        <h3 style="text-align: center;"><?= $berita['judul'] ?></h3>
                        <p style="color: black;"><?= date('d-m-Y', strtotime($berita['tanggal'])) ?></p>
                    </div>
                    <div class="card-body">
                        <br>
                        <p class="paragraf text-black"><?= $berita['isi'] ?></p>
                    </div>
                    <div class="card-footer">
                        <p>footer bagian akhir</p>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>


<!-- Popular Courses -->