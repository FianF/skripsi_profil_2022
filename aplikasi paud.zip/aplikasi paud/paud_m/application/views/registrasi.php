<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/unicat/styles/bootstrap4/bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">
</head>

<body class="bg-mantap">
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-md-8">
                <?php $data = $this->session->flashdata('pesan');
                if ($data) { ?>
                    <div class="alert <?= $data[0] ?> alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <i class="fa <?= $data[2] ?>" aria-hidden="true"></i> <?= $data[1] ?>
                    </div>
                <?php } ?>
                <div class="card card-login">
                    <div class="card-header mb-0">
                        <img class="profile-img rounded-circle" src="<?= base_url('assets/img/sekolah/logo.png'); ?>" alt="logo-sekolah">
                        <h5 class="text-center">Please <span class="font-weight-bold text-primary">Registrasi</span></h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo base_url('Home/prosesReg'); ?>" method="post">
                            <div class="form-group">
                                <label for="">Username</label>
                                <input type="text" name="username" class="form-control" required autofocus>
                            </div>
                            <div class="form-group">
                                <label for="">Password</label>
                                <input type="password" name="password" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="">Konfirmasi Password</label>
                                <input type="password" name="password2" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="">Telp</label>
                                <input type="text" name="telp" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <input type="submit" name="" value="Daftar" class="btn btn-primary btn-block">
                            </div>
                            <div class="form-group">
                                <input type="reset" name="" value="Reset" class="btn btn-secondary btn-block">
                            </div>
                        </form>
                    </div>
                    <div class="card-footer">
                        <label for=""> Sudah punya akun ? </label>
                        <a href="<?php echo base_url('Home/login'); ?>" class="pull-right need-help">login </a><span class="clearfix"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?= base_url() ?>assets/unicat/js/jquery-3.2.1.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/styles/bootstrap4/popper.js"></script>
    <script src="<?= base_url() ?>assets/unicat/styles/bootstrap4/bootstrap.min.js"></script>
</body>

</html>