<div class="row">
	<div class="col m 12">
		<h5>Profil Ruang Baca SMP KP 1 Baleendah</h5>
	</div>
</div>

<div class="row">
	<div class="col m6">
		<div class="card-panel teal darken-2 white-text">
			<h6><b>Visi</b></h6>
			<p align="justify">
				Sekolah Sehat, Disiplin, Berkarya dan Berbudaya Lingkungan.
			</p><br>
			<h6><b>Misi</b></h6>
			<li align="justify">
				Membangun kondisi seluruh warga sekolah yang sehat baik fisik, mental,spiritual dan sosial sebagai karunia Allah yang wajib disyukuri.
			</li>
			<li align="justify">
				Menampilkan karakter disiplin sebagai kepatuhan dalam mentaati peraturan dan ketentuan yang telah ditetapkan.
			</li>
			<li align="justify">
				Membangun warga sekolah yang siap berkarya, giat belajar sampai menghasilkan sesuau yang bermanfaat bagi semua orang.
			</li>
			<li align="justify">
				Merancang tata letak sekolah yang berwawasan lingkungan dengan menerapkan nilai-nilai cinta dan peduli pada lingkungan.			
			</li>			
		</div>
	</div>
    <div class="col m6">
        <div class="card-panel teal darken-2 white-text">
            <center>
            	<h6><b>Tentang Sistem Informasi Ruang Baca</b>
            		<br><b>SMP KP 1 Baleendah</b>
            	</h6>
            </center>
            <hr>
            <p align="justify">SMP KP 1 Baleendah yang beralamat di Jl. Adipati Agung No. 32 Baleendah, Kecamatan Baleendah Kabupaten Bandung Provinsi Jawa Barat adalah lembaga yang bergerak di bidang pendidikan.
           	<p align="justify">Sistem Ruang Baca SMP KP 1 Baleendah adalah tempat para siswa untuk membaca buku-buku yang ada di perpustakaan dari berbagai referensi yang dapat dipertanggungjawabkan kebenarannya.
			<p align="justify">Sistem saat ini melakukan pendataan untuk peminjaman dan pengembalian buku masih secara manual. Meskipun sudah melibatkan komputer, namun hasilnya belum maksimal karena datanya tidak terintegrasi dan pencatatan data ini terlalu banyak sehingga mengakibatkan informasi yang dihasilkan dari proses pengolahan data ini kurang efesien.
			<p align="justify">Oleh karena itulah dibutuhkan suatu sistem informasi ruang baca yang terintegrasi. Sistem ini dapat diharapkan memberikan dukungan dalam mewujudkan suatu proses pengolahan data peminjaman dan pengembalian buku yang efektif dan juga efesien di SMP KP 1 Baleendah.
            </p>
        </div>
    </div>
</div>
