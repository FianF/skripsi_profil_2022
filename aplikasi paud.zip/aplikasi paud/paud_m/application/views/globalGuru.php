<div class="courses">
    <div class="section_background parallax-window" data-parallax="scroll" data-image-src="<?= base_url() ?>assets/unicat/images/courses_background.jpg" data-speed="0.8"></div>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="section_title_container text-center">
                    <h2 class="section_title">Data Guru</h2>
                </div>
            </div>
        </div>
        <div class="row courses_row">

            <!-- Course -->
            <div class="col-lg-12 course_col">
                <div class="card">
                    <div class="card-header">
                        <!-- <h3>Guru</h3> -->
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <?php
                            foreach ($guru as $x) {
                            ?>
                                <div class="col-md-3 gambarSamping" ;>
                                    <center>
                                        <a href="<?= base_url("assets/img/guru/$x->foto_guru"); ?>" target="_blank">
                                            <img class="gambarUtama" src="<?= base_url('assets/img/guru/' . $x->foto_guru); ?>">
                                        </a>
                                    </center>
                                    <h5 style="text-align: center;"><?= $x->nama ?></h5>
                                </div>
                            <?php } ?>
                        </div>
                        <div class="card-footer">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>