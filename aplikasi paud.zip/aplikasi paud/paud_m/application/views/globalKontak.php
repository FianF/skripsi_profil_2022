<div class="courses">
    <div class="section_background parallax-window" data-parallax="scroll" data-image-src="<?= base_url() ?>assets/unicat/images/courses_background.jpg" data-speed="0.8"></div>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="section_title_container text-center">
                    <h2 class="section_title">Kontak</h2>
                </div>
            </div>
        </div>
        <div class="row courses_row">

            <!-- Course -->
            <div class="col-lg-12 course_col">
                <div class="card">
                    <div class="card-header">
                        <!-- <h3></h3> -->
                    </div>
                    <div class="card-body">
                        <table>
                            <tr>
                                <td style="padding-right: 10px;">
                                    <h4>Telepon</h4>
                                </td>
                                <td>
                                    <h4>: <?= $kontak[3]['isi'] ?></h4>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <h4>Email</h4>
                                </td>
                                <td>
                                    <h4>: <?= $kontak[4]['isi'] ?></h4>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div class="card-footer">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>