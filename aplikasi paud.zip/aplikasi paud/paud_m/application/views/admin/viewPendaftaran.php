<!-- end tambah -->

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Tambah data pendaftaran
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <?php $data = $this->session->flashdata('pesan');
                if ($data) { ?>
                    <div class="alert <?= $data[1] ?> alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <i class="fa <?= $data[2] ?>" aria-hidden="true"></i> <?= $data[0] ?>
                    </div>
                <?php } ?>
                <button type="button" class="btn btn-primary btn-sm tombol" title="Tambah data" data-toggle="modal" data-target="#tambah"><i class="fa fa-plus" aria-hidden="true"></i>
                    Tambah
                </button>
                &ensp;
                <button type="button" class="btn btn-success btn-sm tombol" title="Cetak data" data-toggle="modal" data-target="#cetak"><i class="fa fa-print" aria-hidden="true"></i>
                    Cetak
                </button>


                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead class="bg-info">
                            <tr>
                                <th width="5%">No</th>
                                <th width="10%">Tanggal</th>
                                <th>Nama</th>
                                <th>Tempat, tgl lahir</th>
                                <th>Alamat</th>
                                <th>Orang tua/wali</th>
                                <th>Telepon/WA</th>
                                <th width="25%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            foreach ($pendaftaran as $x) {
                            ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= date('d-m-Y', strtotime($x->tanggal)) ?></td>
                                    <td><?= $x->nama ?></td>
                                    <td><?= $x->ttl ?></td>
                                    <td><?= $x->alamat ?></td>
                                    <td><?= $x->ortu ?></td>
                                    <td><?= $x->telp ?></td>
                                    <td>
                                        <button type="button" title="Edit data" class="btn btn-success btn-sm" data-toggle="modal" data-target="#detail<?= $x->id_pendaftaran ?>"><i class="fa fa-id-card" aria-hidden="true"></i>
                                            Detail
                                        </button>
                                        &ensp;
                                        <a class="btn btn-danger btn-sm" title="Hapus data" href='<?= base_url("admin/Pendaftaran/hapus/$x->id_pendaftaran"); ?>' onclick="return confirm('Apakah anda yakin menghapus data <?= $x->nama ?> ini ?');"><i class="fa fa-trash"></i> Hapus</a>
                                        &ensp;
                                        <button type="button" title="Edit data" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#edit<?= $x->id_pendaftaran ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                            Edit
                                        </button>
                                    </td>
                                </tr>

                                <!-- detail -->
                                <!-- edit -->
                                <div class="modal fade" id="detail<?= $x->id_pendaftaran ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                                <h3 class="modal-title" id="exampleModalLabel">Detail pendaftaran</h3>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-4">Nama</div>
                                                    <div class="col-md-8">: <?= $x->nama ?></div>
                                                    <div class="col-md-4">Jenis kelamin</div>
                                                    <div class="col-md-8">: <?= $x->jk ?></div>
                                                    <div class="col-md-4">Tempat, tanggal lahir</div>
                                                    <div class="col-md-8">: <?= $x->ttl ?></div>
                                                    <div class="col-md-4">ALamat</div>
                                                    <div class="col-md-8">: <?= $x->alamat ?></div>
                                                    <div class="col-md-4">Agama</div>
                                                    <div class="col-md-8">: <?= $x->agama ?></div>
                                                    <div class="col-md-4">Orang tua/wali</div>
                                                    <div class="col-md-8">: <?= $x->ortu ?></div>
                                                    <div class="col-md-4">Telepon/WA</div>
                                                    <div class="col-md-8">: <?= $x->telp ?></div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- edit -->
                                <div class="modal fade" id="edit<?= $x->id_pendaftaran ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                                <h3 class="modal-title" id="exampleModalLabel">Edit pendaftaran</h3>
                                            </div>
                                            <form action="<?= base_url('admin/Pendaftaran/update'); ?>" method="post">
                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <input type="hidden" name="id_pendaftaran" value="<?= $x->id_pendaftaran ?>" id="">
                                                        <label for="">Nama</label>
                                                        <input type="text" name="nama" value="<?= $x->nama ?>" class="form-control" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Jenis kelamin</label>
                                                        <select name="jk" id="jk" class="form-control">
                                                            <option value="Laki-laki" <?= ($x->jk == "Laki-laki") ? 'selected' : '' ?>>Laki-laki</option>
                                                            <option value="Perempuan" <?= ($x->jk == "Perempuan") ? 'selected' : '' ?>>Perempuan</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Tempat, tanggal lahir</label>
                                                        <input type="text" name="ttl" value="<?= $x->ttl ?>" class="form-control" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Alamat</label>
                                                        <input type="text" name="alamat" value="<?= $x->alamat ?>" class="form-control" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Agama</label>
                                                        <input type="text" name="agama" value="<?= $x->agama ?>" class="form-control" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Orang tua/Wali</label>
                                                        <input type="text" name="ortu" value="<?= $x->ortu ?>" class="form-control" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Telepon/WA</label>
                                                        <input type="text" name="telp" value="<?= $x->telp ?>" class="form-control" required>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-primary">Update</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        </tbody>
                    </table>
                    <div class="modal fade" id="cetak" tabindex="-1" aria-labelledby="exampleModalCetak" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <h3 class="modal-title" id="exampleModalCetak">cetak pendaftaran</h3>
                                </div>
                                <form action="<?= base_url('admin/Pendaftaran/cetak'); ?>" target="_blank" method="post">
                                    <div class="modal-body">

                                        <div class="form-group">
                                            <label for="">Tanggal mulai</label>
                                            <input type="date" name="tanggalMulai" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="">Tanggal selesai</label>
                                            <input type="date" name="tanggalSelesai" class="form-control">
                                        </div>
                                        <div class="modal-footer">
                                            <button type="reset" class="btn btn-secondary">Reset</button>
                                            <button type="submit" class="btn btn-primary">Cetak</button>
                                        </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>

<div class="modal fade" id="tambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h3 class="modal-title" id="exampleModalLabel">Tambah pendaftaran</h3>
            </div>
            <form action="<?= base_url('admin/Pendaftaran/simpan'); ?>" method="post">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="">Nama</label>
                        <input type="text" name="nama" class="form-control" autofocus required>
                    </div>
                    <div class="form-group">
                        <label for="">Jenis kelamin</label>
                        <select name="jk" id="jk" class="form-control">
                            <option value="Laki-laki">Laki-laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Tempat, tanggal lahir</label>
                        <input type="text" name="ttl" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Alamat</label>
                        <input type="text" name="alamat" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Agama</label>
                        <input type="text" name="agama" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Orang tua/wali</label>
                        <input type="text" name="ortu" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Telepon/WA</label>
                        <input type="text" name="telp" class="form-control" required>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-secondary">Reset</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
            </form>
        </div>
    </div>
</div>