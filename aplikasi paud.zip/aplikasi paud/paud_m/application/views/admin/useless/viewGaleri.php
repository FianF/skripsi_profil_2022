<!-- tambah -->
<div class="modal fade" id="tambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="exampleModalLabel">Tambah Galeri</h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= base_url('admin/Galeri/simpan'); ?>" method="post" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="">Gambar</label>
                        <input type="file" name="gambar" class="form-control">
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="reset" class="btn btn-secondary">Reset</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- end tambah -->

<div class="courses">
    <div class="section_background parallax-window" data-parallax="scroll" data-image-src="<?= base_url() ?>assets/unicat/images/courses_background.jpg" data-speed="0.8"></div>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="section_title_container text-center">
                    <h2 class="section_title">Daftar data galeri</h2>
                </div>
            </div>
        </div>
        <div class="row courses_row">

            <!-- Course -->
            <div class="col-lg-12 course_col">
                <div class="card">
                    <div class="card-header">
                        <h3>Tabel data galeri</h3>
                    </div>
                    <div class="card-body">
                        <?php $data = $this->session->flashdata('pesan');
                        if ($data) { ?>
                            <div class="alert <?= $data[1] ?> alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <i class="fa <?= $data[2] ?>" aria-hidden="true"></i> <?= $data[0] ?>
                            </div>
                        <?php } ?>
                        <button type="button" class="btn btn-primary btn-sm" title="Tambah data" style="margin-bottom: 10px;" data-toggle="modal" data-target="#tambah"><i class="fa fa-plus" aria-hidden="true"></i>
                            Tambah
                        </button>
                        <table class="table table-bordered table-hover table-stripped" id="myTable">
                            <thead class="bg-success">
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Gambar</th>
                                    <th width="20%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                foreach ($galeri as $x) {
                                ?>
                                    <tr>
                                        <td><?= $no++ ?></td>
                                        <td>
                                            <a href="<?= base_url("assets/img/galeri/$x->gambar"); ?>" target="_blank">
                                                <img style="height: 200px;" src="<?= base_url('assets/img/galeri/' . $x->gambar); ?>">
                                            </a>
                                        </td>
                                        <td>
                                            <a class="btn btn-danger btn-sm" title="Hapus data" href='<?= base_url("admin/Galeri/hapus/$x->id_galeri"); ?>' onclick="return confirm('Apakah anda yakin menghapus data galeri ini ?');"><i class="fa fa-trash"></i> Hapus</a>
                                            &ensp;
                                            <button type="button" title="Edit data" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#edit<?= $x->id_galeri ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                                Edit
                                            </button>

                                            <!-- tambah -->
                                            <div class="modal fade" id="edit<?= $x->id_galeri ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h3 class="modal-title" id="exampleModalLabel">Edit pengguna</h3>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <form action="<?= base_url('admin/Siswa/update'); ?>" method="post" enctype="multipart/form-data">
                                                            <div class="modal-body">
                                                                <div class="form-group">
                                                                    <input type="hidden" name="id_galeri" value="<?= $x->id_galeri ?>" id="">
                                                                    <label for="">Gambar</label>
                                                                    <input type="file" name="gambar" class="form-control">
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                                                <button type="submit" class="btn btn-primary">Update</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>

                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                        <div class="card-footer">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>