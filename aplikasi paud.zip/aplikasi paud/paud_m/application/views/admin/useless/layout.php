<!DOCTYPE html>
<html lang="en">

<head>
    <title><?= $judul ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Unicat project">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/unicat/styles/bootstrap4/bootstrap.min.css'); ?>">
    <link href="<?= base_url('assets/unicat/plugins/font-awesome-4.7.0/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/unicat/plugins/OwlCarousel2-2.2.1/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/unicat/plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/unicat/plugins/OwlCarousel2-2.2.1/animate.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/unicat/styles/main_styles.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/unicat/styles/responsive.css">

    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <style>
        tr td,
        label {
            color: black;
        }

        tr th {
            color: white;
        }
    </style>
</head>

<body>

    <div class="super_container">

        <!-- Header -->

        <header class="header">

            <!-- Top Bar -->
            <div class="top_bar">
                <div class="top_bar_container">
                    <div class="container">
                        <div class="row">
                            <div class="col">
                                <div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
                                    <ul class="top_bar_contact_list">
                                        <li>
                                            <div class="question">Have any questions?</div>
                                        </li>
                                        <li>
                                            <i class="fa fa-phone" aria-hidden="true"></i>
                                            <div>001-1234-88888</div>
                                        </li>
                                        <li>
                                            <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                            <div>info.deercreative@gmail.com</div>
                                        </li>
                                    </ul>
                                    <div class="top_bar_login ml-auto">
                                        <div class="login_button"><a href="<?= base_url('/Home/logout'); ?>" onclick="return confirm('Apakah anda yakin untuk log out akun <?= $this->session->userdata('username'); ?> ini ?');">Log out</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Header Content -->
            <div class="header_container">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <div class="header_content d-flex flex-row align-items-center justify-content-start">
                                <div class="logo_container">
                                    <a href="#">
                                        <div class="logo"><img class="profile-img rounded-circle" src="<?= base_url('assets/img/sekolah/logo.png'); ?>" alt="logo-sekolah"></div>
                                    </a>
                                </div>
                                <nav class="main_nav_contaner ml-auto">
                                    <ul class="main_nav">
                                        <li class="<?= ($judul == 'Home') ? 'active' : '' ?>"><a href="<?= base_url('admin/Home'); ?>"><i class="fa fa-home"></i> Home</a></li>
                                        <li class="<?= ($judul == 'Guru' || $judul == 'Siswa' || $judul == 'Pengguna') ? 'active' : '' ?>"><a class="nav-link dropdown-toggle" href="#" id="navbarDropdownData" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Data</a>
                                            <div class="dropdown-menu" aria-labelledby="navbarDropdownData">
                                                <a class="dropdown-item" href="<?= base_url('admin/Guru'); ?>"><i class="fa fa-user"></i> Data Guru</a>
                                                <a class="dropdown-item" href="<?= base_url('admin/Siswa'); ?>"><i class="fa fa-users"></i> Data Siswa</a>
                                                <a class="dropdown-item" href="<?= base_url('admin/Pengguna'); ?>"><i class="fa fa-user"></i> Data Pengguna</a>
                                            </div>
                                        </li>
                                        <li class="<?= ($judul == 'Berita' || $judul == 'Galeri' || $judul == 'Pengumuman') ? 'active' : '' ?>"><a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPeristiwa" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Peristiwa</a>
                                            <div class="dropdown-menu" aria-labelledby="navbarDropdownPeristiwa">
                                                <a class="dropdown-item" href="<?= base_url('admin/Berita'); ?>"><i class="fa fa-tags"></i> Data Berita</a>
                                                <a class="dropdown-item" href="<?= base_url('admin/Galeri'); ?>"><i class="fa fa-tags"></i> Data Galeri</a>
                                                <!-- <div class="dropdown-divider"></div> -->
                                                <a class="dropdown-item" href="<?= base_url('admin/Pengumuman'); ?>"><i class="fa fa-tags"></i> Data Pengumuman</a>
                                            </div>
                                        </li>
                                    </ul>
                                    <div class="search_button"><i class="fa fa-search" aria-hidden="true"></i></div>

                                    <!-- Hamburger -->

                                    <div class="shopping_cart"><i class="fa fa-shopping-cart" aria-hidden="true"></i></div>
                                    <div class="hamburger menu_mm">
                                        <i class="fa fa-bars menu_mm" aria-hidden="true"></i>
                                    </div>
                                </nav>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Header Search Panel -->
            <div class="header_search_container">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <div class="header_search_content d-flex flex-row align-items-center justify-content-end">
                                <form action="#" class="header_search_form">
                                    <input type="search" class="search_input" placeholder="Search" required="required">
                                    <button class="header_search_button d-flex flex-column align-items-center justify-content-center">
                                        <i class="fa fa-search" aria-hidden="true"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <main style="padding-top: 75px;">
            <?php
            $this->load->view($content);
            ?>

        </main>
        <footer class="footer">
            <div class="footer_background" style="background-image:url(<?= base_url() ?>assets/unicat/images/footer_background.png)"></div>
            <div class="container">
                <div class="row footer_row">
                    <div class="col">
                        <div class="footer_content">
                            <div class="row">

                                <div class="col-lg-3 footer_col">

                                    <!-- Footer About -->
                                    <div class="footer_section footer_about">
                                        <div class="footer_logo_container">
                                            <a href="#">
                                                <div class="footer_logo_text">Unic<span>at</span></div>
                                            </a>
                                        </div>
                                        <div class="footer_about_text">
                                            <p>Lorem ipsum dolor sit ametium, consectetur adipiscing elit.</p>
                                        </div>
                                        <div class="footer_social">
                                            <ul>
                                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>

                                <div class="col-lg-3 footer_col">

                                    <!-- Footer Contact -->
                                    <div class="footer_section footer_contact">
                                        <div class="footer_title">Contact Us</div>
                                        <div class="footer_contact_info">
                                            <ul>
                                                <li>Email: Info.deercreative@gmail.com</li>
                                                <li>Phone: +(88) 111 555 666</li>
                                                <li>40 Baria Sreet 133/2 New York City, United States</li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>

                                <div class="col-lg-3 footer_col">

                                    <!-- Footer links -->
                                    <div class="footer_section footer_links">
                                        <div class="footer_title">Contact Us</div>
                                        <div class="footer_links_container">
                                            <ul>
                                                <li><a href="index.html">Home</a></li>
                                                <li><a href="about.html">About</a></li>
                                                <li><a href="contact.html">Contact</a></li>
                                                <li><a href="#">Features</a></li>
                                                <li><a href="courses.html">Courses</a></li>
                                                <li><a href="#">Events</a></li>
                                                <li><a href="#">Gallery</a></li>
                                                <li><a href="#">FAQs</a></li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>

                                <div class="col-lg-3 footer_col clearfix">

                                    <!-- Footer links -->
                                    <div class="footer_section footer_mobile">
                                        <div class="footer_title">Mobile</div>
                                        <div class="footer_mobile_content">
                                            <div class="footer_image"><a href="#"><img src="<?= base_url() ?>assets/unicat/images/mobile_1.png" alt=""></a></div>
                                            <div class="footer_image"><a href="#"><img src="<?= base_url() ?>assets/unicat/images/mobile_2.png" alt=""></a></div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="row copyright_row">
                    <div class="col">
                        <div class="copyright d-flex flex-lg-row flex-column align-items-center justify-content-start">
                            <div class="cr_text">
                                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                                Copyright &copy;<script>
                                    document.write(new Date().getFullYear());
                                </script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
                                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            </div>
                            <div class="ml-lg-auto cr_links">
                                <ul class="cr_list">
                                    <li><a href="#">Copyright notification</a></li>
                                    <li><a href="#">Terms of Use</a></li>
                                    <li><a href="#">Privacy Policy</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <script src="<?= base_url() ?>assets/unicat/js/jquery-3.2.1.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/styles/bootstrap4/popper.js"></script>
    <script src="<?= base_url() ?>assets/unicat/styles/bootstrap4/bootstrap.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/plugins/greensock/TweenMax.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/plugins/greensock/TimelineMax.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/plugins/scrollmagic/ScrollMagic.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/plugins/greensock/animation.gsap.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/plugins/greensock/ScrollToPlugin.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
    <script src="<?= base_url() ?>assets/unicat/plugins/easing/easing.js"></script>
    <script src="<?= base_url() ?>assets/unicat/plugins/parallax-js-master/parallax.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/js/custom.js"></script>

    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#myTable').DataTable();
        });
    </script>
</body>

</html>