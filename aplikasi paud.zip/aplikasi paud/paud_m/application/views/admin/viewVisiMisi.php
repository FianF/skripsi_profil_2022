<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Data Visi Misi
                <button type="button" title="Edit data" class="btn-kanan btn btn-warning btn-sm" data-toggle="modal" data-target="#edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                    Edit
                </button>
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <?php $data = $this->session->flashdata('pesan');
                if ($data) { ?>
                    <div class="alert <?= $data[1] ?> alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <i class="fa <?= $data[2] ?>" aria-hidden="true"></i> <?= $data[0] ?>
                    </div>
                <?php } ?>
                <h3>Visi</h3>
                <hr>
                <h4><?= $visiMisi[1]['isi'] ?></h4>
                <br>
                <br>
                <h3>Misi</h3>
                <hr>
                <h5><?= $visiMisi[2]['isi'] ?></h5>
                <div class="table-responsive">

                    <!-- edit -->
                    <div class="modal fade" id="edit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <h3 class="modal-title" id="exampleModalLabel">Edit pengumuman</h3>
                                </div>
                                <form action="<?= base_url('admin/Profil/updateVisiMisi'); ?>" method="post">
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label for="">Visi</label>
                                            <input type="text" name="visi" value="<?= $visiMisi[1]['isi'] ?>" class="form-control" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Misi</label>
                                            <input type="text" name="misi" value="<?= $visiMisi[2]['isi'] ?>" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>