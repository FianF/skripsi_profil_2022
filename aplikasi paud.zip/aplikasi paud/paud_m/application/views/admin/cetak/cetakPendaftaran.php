<html lang="en">

<head>
    <title>.</title>
</head>
<style>
    body {
        font-family: 'Times New Roman', Times, serif;
    }

    th {
        background-color: #ccc;
    }

    tr td {
        vertical-align: middle;
    }
</style>
<link rel="stylesheet" href="<?= base_url(); ?>assets/plugins/datatables/dataTables.bootstrap.css">

<body>
    <img src="<?= base_url('assets/img/sekolah/logo.png'); ?>" style="position: absolute; width: 50px; height:auto">
    <br>
    <table style="width: 100%; ">
        <tr>
            <td align="center">
                <span style="line-height: 1.6; font-weight: bold;">
                    PAUD MAWARSARI 6
                </span>
            </td>
        </tr>
    </table>
    <br>
    <hr size="2" color="black">
    <center>
        <H5><b>TABEL PENDAFTARAN</b></H5>
        <table border="1" style="font-size: 12px; border-collapse: collapse;" width="100%">
            <thead class="bg-success">
                <tr>
                    <th width="5%">No</th>
                    <th width="10%">Tanggal</th>
                    <th>Nama</th>
                    <th>Tempat, tgl lahir</th>
                    <th>Alamat</th>
                    <th>Orang tua/wali</th>
                    <th>Telepon/WA</th>
                </tr>
            </thead>

            <tbody>
                <?php
                $no = 1;
                foreach ($cetakPendaftaran as $x) {
                ?>
                    <tr>
                        <td align="center" width="5%"><?= $no++; ?></td>
                        <td><?= date('d-m-Y', strtotime($x-> tanggal)) ?></td>
                        <td><?= $x-> nama ?></td>
                        <td><?= $x-> ttl ?></td>
                        <td><?= $x-> alamat ?></td>
                        <td><?= $x-> ortu ?></td>
                        <td><?= $x-> telp ?></td>
                    <?php
                }
                    ?>
            </tbody>
        </table>
    </center>
    <script type="text/javascript">
        window.print();
    </script>
</body>

</html>