<html lang="en">

<head>
    <title>
        cetak guru
    </title>
</head>
<style>
    body {
        font-family: 'Times New Roman', Times, serif;
    }

    th {
        background-color: #ccc;
    }

    tr td {
        vertical-align: middle;
    }
</style>
<link rel="stylesheet" href="<?= base_url(); ?>assets/plugins/datatables/dataTables.bootstrap.css">

<body>
    <img src="<?= base_url('assets/img/sekolah/logo.png'); ?>" style="position: absolute; width: 50px; height:auto">
    <br>
    <table style="width: 100%; ">
        <tr>
            <td align="center">
                <span style="line-height: 1.6; font-weight: bold;">
                    PAUD MAWARSARI 6
                </span>
            </td>
        </tr>
    </table>
    <br>
    <hr size="2" color="black">
    <center>
        <H5><b>TABEL GURU</b></H5>
        <table border="1" style="font-size: 12px; border-collapse: collapse;" width="100%">
            <thead class="bg-success">
                <tr>
                    <th>No</th>
                    <th width="20%">Nama</th>
                    <th width="40%">Alamat</th>
                    <th width="10%">Telepon</th>
                    <th width="25%">Foto</th>
                </tr>
            </thead>

            <tbody>
                <?php
                $no = 1;
                foreach ($cetakGuru as $x) {
                ?>
                    <tr>
                        <td align="center" width="5%"><?= $no++; ?></td>
                        <td><?= $x->nama; ?> </td>
                        <td><?= $x->alamat ?></td>
                        <td style="text-align: right;"><?= $x->telp ?></td>
                        <td>
                            <center>
                                <img style="height: 100px;" src="<?= base_url('assets/img/guru/' . $x->foto_guru); ?>">
                            </center>
                        </td>
                    <?php
                }
                    ?>
            </tbody>
        </table>
    </center>
    <script type="text/javascript">
        window.print();
    </script>
</body>

</html>