<div class="modal fade" id="tambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h3 class="modal-title" id="exampleModalLabel">Tambah berita</h3>
            </div>
            <form action="<?= base_url('admin/Berita/simpan'); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="">Judul</label>
                        <input type="text" name="judul" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Isi berita</label>
                        <textarea name="isi" id="" class="form-control" cols="30" rows="10" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Foto</label>
                        <input type="file" name="foto" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="reset" class="btn btn-secondary">Reset</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- end tambah -->

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Tambah data berita
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <?php $data = $this->session->flashdata('pesan');
                if ($data) { ?>
                    <div class="alert <?= $data[1] ?> alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <i class="fa <?= $data[2] ?>" aria-hidden="true"></i> <?= $data[0] ?>
                    </div>
                <?php } ?>
                <button type="button" class="btn btn-primary btn-sm" title="Tambah data" style="margin-bottom: 10px;" data-toggle="modal" data-target="#tambah"><i class="fa fa-plus" aria-hidden="true"></i>
                    Tambah
                </button>
                <div class="table-responsivex">
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead class="bg-info">
                            <tr>
                                <th width="5%">No</th>
                                <th>Foto</th>
                                <th>Judul</th>
                                <th>Isi berita</th>
                                <th>Tanggal</th>
                                <th width="20%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            foreach ($berita as $x) {
                            ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td>
                                        <a href="<?= base_url("assets/img/siswa/$x->foto"); ?>" target="_blank">
                                            <img style="height: 80px;" src="<?= base_url('assets/img/berita/' . $x->foto); ?>">
                                        </a>
                                    </td>
                                    <td><?= $x->judul ?></td>
                                    <td class="paragraf"><?= $x->isi ?></td>
                                    <td><?= date('d-m-Y', strtotime($x->tanggal)) ?></td>
                                    <td>
                                        <a class="btn btn-danger btn-sm" title="Hapus data" href='<?= base_url("admin/Berita/hapus/$x->id_berita"); ?>' onclick="return confirm('Apakah anda yakin menghapus data <?= $x->judul ?> ini ?');"><i class="fa fa-trash"></i> Hapus</a>
                                        &ensp;
                                        <button type="button" title="Edit data" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#edit<?= $x->id_berita ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                            Edit
                                        </button>
                                    </td>
                                </tr>

                                <!-- edit -->
                                <div class="modal fade" id="edit<?= $x->id_berita ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                                <h3 class="modal-title" id="exampleModalLabel">Edit berita</h3>
                                            </div>
                                            <form action="<?= base_url('admin/Berita/update'); ?>" method="post" enctype="multipart/form-data">
                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <input type="hidden" name="id_berita" value="<?= $x->id_berita ?>" id="">
                                                        <label for="">Judul</label>
                                                        <input type="text" name="judul" value="<?= $x->judul ?>" class="form-control" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Isi berita</label>
                                                        <textarea name="isi" id="" class="form-control" cols="30" rows="10" required><?= $x->isi ?></textarea>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Foto</label>
                                                        <input type="file" name="foto" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-primary">Update</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>