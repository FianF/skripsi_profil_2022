<div class="courses">
    <div class="section_background parallax-window" data-parallax="scroll" data-image-src="<?= base_url() ?>assets/unicat/images/courses_background.jpg" data-speed="0.8"></div>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="section_title_container text-center">
                    <h2 class="section_title">Data Siswa</h2>
                </div>
            </div>
        </div>
        <div class="row courses_row">

            <!-- Course -->
            <div class="col-lg-12 course_col">
                <div class="card">
                    <div class="card-header">
                        <!-- <h3>Siswa</h3> -->
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <?php
                            foreach ($siswa as $x) {
                            ?>
                                <div class="col-md-3 gambarSamping" ;>
                                    <center>
                                        <a href="<?= base_url("assets/img/siswa/$x->foto"); ?>" target="_blank">
                                            <img class="gambarUtama" src="<?= base_url('assets/img/siswa/' . $x->foto); ?>">
                                        </a>
                                        <table class="tb-atas">
                                            <tr>
                                                <td>Nama</td>
                                                <td>:</td>
                                                <td><?= $x->nama ?></td>
                                            </tr>
                                            <tr>
                                                <td>Kelas</td>
                                                <td>:</td>
                                                <td><?= $x->kelas ?></td>
                                            </tr>
                                        </table>
                                    </center>
                                </div>
                            <?php } ?>
                        </div>


                        <div class="card-footer">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>