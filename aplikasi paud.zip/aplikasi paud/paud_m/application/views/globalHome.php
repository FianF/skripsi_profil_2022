<style>
    .tabel {
        text-align: justify;
        padding-right: 15px;
        vertical-align: top;
    }

    p {
        color: black;
        margin: 0;
    }

    .tb {
        border: 1px solid black;
        margin: 0 100px 20px 100px;
    }

    /* a:link {
        color: blue;
    }

    a:visited {
        color: hotpink;
    }

    a:hover {
        color: white;
        background-color: blue;
    } */
</style>
<div class="home">
    <div class="home_slider_container">

        <!-- Home Slider -->
        <div class="owl-carousel owl-theme home_slider" wight="100" hight="100">

            <!-- Home Slider Item -->
            <?php foreach ($galeri as $x) { ?>
                <div class="owl-item">
                    <div class="home_slider_background" style="background-image:url(<?= base_url('assets/img/galeri/' . $x->gambar); ?>)"></div>
                    <!-- <div class="home_slider_content">
                        <div class="container">
                            <div class="row">
                                <div class="col text-center">
                                    <h1 style="color: white;"></h1>
                                </div>
                            </div>
                        </div>
                    </div> -->
                </div>
            <?php } ?>

        </div>
    </div>

    <!-- Home Slider Nav -->

    <div class="home_slider_nav home_slider_prev"><i class="fa fa-angle-left" aria-hidden="true"></i></div>
    <div class="home_slider_nav home_slider_next"><i class="fa fa-angle-right" aria-hidden="true"></i></div>
</div>

<div class="courses" style="padding:0 ">
    <div class="section_background parallax-window" data-parallax="scroll" data-image-src="<?= base_url() ?>assets/unicat/images/courses_background.jpg" data-speed="0.8"></div>
    <div class="container">
        <center>
            <div class="card">
                <div class="card-header">
                    <h3>Tahapan Pendaftaran</h3>
                </div>
                <div class="card-body">
                    <table width="100%" class="tabel">
                        <tr>
                            <td class="tabel" width="22%">Buat akun untuk mendapatkan hak ases login ke form pendaftaran, dengan cara klik link pendaftaran dibawah atau klik tombol daftar di bagian kanan atas.</td>
                            <td width="4%"> <i class="fa fa-3x fa-arrow-right" aria-hidden="true"></i></td>
                            <td class="tabel" width="22%">Login dengan username dan pasword yang telah bapak/ibu buat sebelumnya</td>
                            <td width="4%"> <i class="fa fa-3x fa-arrow-right" aria-hidden="true"></i></td>
                            <td class="tabel" width="22%">Bapak/Ibu mengisi form pendaftaran siswa </td>
                            <td width="4%"> <i class="fa fa-3x fa-arrow-right" aria-hidden="true"></i></td>
                            <td class="tabel" width="22%"> Selanjutnya, tunggu tim kami menghubungi bapa/Ibu atau hubungi kontak kami untuk informasi lebih lanjut untuk pendaftaran siswa</td>
                        </tr>
                    </table>
                </div>
                <div class="card-footer">
                    <a href="<?= base_url('/Home/login'); ?>">Klik link ini untuk mendaftar</a>
                </div>
            </div>
        </center>

    </div>
</div>

<!-- Features -->

<div class="features" style="padding: 20px 0 15px 0;">
    <div class="container">
        <center>
            <h3 style="margin-bottom: 20px;">Berita</h3>
        </center>
        <?php foreach ($berita as $x) { ?>
            <table class="tb" width="80%">
                <tr>
                    <td width="10%" style="border: 1px solid black;">
                        <center>
                            <img style="width: 100px;" src="<?= base_url('assets/img/berita/' . $x->foto); ?>" alt="logo-sekolah">
                        </center>
                    </td>
                    <td width="70%">
                        <div style="padding: 10px;">
                            <h3><?= $x->judul ?></h3>
                            <p class="paragraf"><?= substr($x->isi, 0, 200) . '...' ?> <a style="text-decoration: none;" href="<?= base_url("Home/detail_berita/$x->id_berita"); ?>"> lihat selengkapnya..</a></p>

                            <p><?= date('d-m-Y', strtotime($x->tanggal)) ?></p>
                        </div>
                    </td>
                </tr>
            </table>



        <?php } ?>
    </div>
</div>

<!-- Popular Courses -->