<!-- <a href="<?= base_url('/Home/login'); ?>">MASUK</a>
<a class="btn green" href="<?= base_url('/Home/login'); ?>">Daftar</a> -->
<!DOCTYPE html>
<html lang="en">

<head>
    <title><?= $judul ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Unicat project">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/unicat/styles/bootstrap4/bootstrap.min.css'); ?>">
    <link href="<?= base_url('assets/unicat/plugins/font-awesome-4.7.0/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/unicat/plugins/OwlCarousel2-2.2.1/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/unicat/plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/unicat/plugins/OwlCarousel2-2.2.1/animate.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/unicat/styles/main_styles.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/unicat/styles/responsive.css">

    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <!-- <link href="<?= base_url('assets/admin/') ?>css/dataTables/dataTables.bootstrap.css" rel="stylesheet"> -->

    <!-- DataTables Responsive CSS -->
    <!-- <link href="<?= base_url('assets/admin/') ?>css/dataTables/dataTables.responsive.css" rel="stylesheet"> -->
    <style>
        tr td,
        label {
            color: black;
        }

        tr th {
            color: white;
        }

        footer {
            padding: 2%;
            text-align: center;
            color: white;
            background-color: gray;
        }

        .gambarSamping {
            padding: 0 1% 2% 1%;
        }

        .gambarUtama {
            height: 150px;
            margin-bottom: 2%;
        }

        .tb-atas tr td {
            vertical-align: top;
            padding-right: 5px;
        }

        .paragraf {
            text-indent: 1cm;
            text-align: justify;
        }
    </style>
</head>

<body>

    <div class="super_container">

        <!-- Header -->

        <header class="header">
            <!-- Top Bar -->
            <div class="top_bar">
                <div class="top_bar_container">
                    <div class="container">
                        <div class="row">
                            <div class="col">
                                <div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
                                    <ul class="top_bar_contact_list">
                                        <li>
                                            <div class="question">Jalan Cikoneng Rt. 01 Rw. 06 Ds. Bojongsoang Kec. Bojongsoang </div>
                                        </li>
                                    </ul>
                                    <div class="top_bar_login ml-auto">
                                        <div class="login_button"><a href="<?= base_url('/Home/login'); ?>">Login atau daftar</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Header Content -->
            <div class="header_container">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <div class="header_content d-flex flex-row align-items-center justify-content-start">
                                <div class="logo_container">
                                    <table>
                                        <tr>
                                            <td>
                                                <img class="rounded-circle" style="width: 50px;" src="<?= base_url('assets/img/sekolah/logo.png'); ?>" alt="logo-sekolah">
                                            </td>
                                            <td>
                                                <h4 style="margin-left: 5px;">PAUD Mawarsari 6</h4>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                                <nav class="main_nav_contaner ml-auto">
                                    <ul class="main_nav">
                                        <li class="<?= ($judul == 'Home') ? 'active' : '' ?> "><a href="<?= base_url('Home'); ?>">Home</a></li>
                                        <li class="nav-item dropdown <?= ($judul == 'Tentang' || $judul == 'Visi Misi' || $judul == 'Struktur' || $judul == 'Fasilitas' || $judul == 'Galeri') ? 'active' : '' ?>">
                                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Profil</a>
                                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                <a class="dropdown-item <?= ($judul == 'Tentang') ? 'active' : '' ?>" href="<?= base_url('Home/tentang'); ?>">Tentang kami</a>
                                                <a class="dropdown-item <?= ($judul == 'Visi Misi') ? 'active' : '' ?>" href="<?= base_url('Home/visiMisi'); ?>">Visi Misi</a>
                                                <a class="dropdown-item <?= ($judul == 'Struktur') ? 'active' : '' ?>" href="<?= base_url('Home/struktur'); ?>">Struktur Organisasi</a>
                                                <a class="dropdown-item <?= ($judul == 'Fasilitas') ? 'active' : '' ?>" href="<?= base_url('Home/fasilitas'); ?>">Fasilitas</a>
                                                <a class="dropdown-item <?= ($judul == 'Galeri') ? 'active' : '' ?>" href="<?= base_url('Home/galeri'); ?>">Galeri</a>
                                            </div>
                                        </li>
                                        <li class="nav-item dropdown <?= ($judul == 'Guru' || $judul == 'Siswa') ? 'active' : '' ?>">
                                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Data</a>
                                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                <a class="dropdown-item <?= ($judul == 'Guru') ? 'active' : '' ?> " href="<?= base_url('Home/guru'); ?>">Guru</a>
                                                <a class="dropdown-item <?= ($judul == 'Siswa' || $judul == 'Siswa') ? 'active' : '' ?>" href="<?= base_url('Home/siswa'); ?>">Siswa</a>
                                            </div>
                                        </li>
                                        <li class="<?= ($judul == 'Pengumuman') ? 'active' : '' ?> "><a href="<?= base_url('Home/pengumuman'); ?>">Pengumuman</a></li>
                                        <li class="<?= ($judul == 'Kontak') ? 'active' : '' ?> "><a href="<?= base_url('Home/kontak'); ?>">Kontak</a></li>
                                    </ul>
                                </nav>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Home -->
        <main>
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header"><?= $judul ?></h1>
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                    <?php
                    $this->load->view($content);
                    ?>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
        </main>
        <footer>
            <h5 style="color: white;">Copyright &copy; 2022 PAUD Mawarsari 6</h5>
        </footer>
        <!-- Footer -->

        <!-- <footer class="footer">
            <div class="footer_background" style="background-image:url(<?= base_url() ?>assets/unicat/images/footer_background.png)"></div> -->
        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
        <!-- Copyright &copy;
            2022 PAUD Mawarsari 6 -->
        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
        <!-- </footer> -->
    </div>

    <script src="<?= base_url() ?>assets/unicat/js/jquery-3.2.1.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/styles/bootstrap4/popper.js"></script>
    <script src="<?= base_url() ?>assets/unicat/styles/bootstrap4/bootstrap.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/plugins/greensock/TweenMax.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/plugins/greensock/TimelineMax.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/plugins/scrollmagic/ScrollMagic.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/plugins/greensock/animation.gsap.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/plugins/greensock/ScrollToPlugin.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
    <script src="<?= base_url() ?>assets/unicat/plugins/easing/easing.js"></script>
    <script src="<?= base_url() ?>assets/unicat/plugins/parallax-js-master/parallax.min.js"></script>
    <script src="<?= base_url() ?>assets/unicat/js/custom.js"></script>

    <!-- <script src="<?= base_url('assets/admin/') ?>js/dataTables/jquery.dataTables.min.js"></script>
    <script src="<?= base_url('assets/admin/') ?>js/dataTables/dataTables.bootstrap.min.js"></script> -->
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#myTable').DataTable();
        });
    </script>
</body>

</html>