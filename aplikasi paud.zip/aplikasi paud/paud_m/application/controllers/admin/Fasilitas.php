<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Fasilitas extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $cek = $this->session->userdata('logged_in');
        $status = $this->session->userdata('status');
        if (($cek) && $status == 'admin') {
            $data['judul'] = 'Fasilitas';
            $data['content'] = 'admin/viewFasilitas';
            $data['fasilitas'] = $this->Paud_model->bacaData('tb_fasilitas')->result();
            $this->load->view('admin/layout', $data);
        } else {
            header('location:' . base_url('Home'));
        }
    }

    public function hapus($id)
    {
        $this->Paud_model->hapusData('tb_fasilitas', 'id_fasilitas', $id);
        $pesan = array('Data berhasil dihapus..', 'alert-danger', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Fasilitas', 'refresh');
    }
    public function update()
    {
        $x = 1;
        $gambar = $_FILES['foto']['name'];
        if ($gambar) {
            $alphanum = "abcdefghijklmnopqrstuvwxyz0123456789";
            $nama = str_shuffle($alphanum); //random nama dengan alphanum
            $config['file_name'] = $nama;
            $config['upload_path'] = "assets/img/fasilitas"; // lokasi penyimpanan file
            $config['allowed_types'] = 'gif|jpg|jpeg|png|JPEG|BMP|bmp'; // format foto yang diizinkan 
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            if ($this->upload->do_upload('foto')) {
                $gambar = $this->upload->file_name;
                $x = 0;
            }
        }

        $id = $this->input->post('id_fasilitas');
        $data['deskripsi'] = $this->input->post('deskripsi');
        if ($x == 0) {
            $data['foto'] = $gambar;
        }

        $this->Paud_model->updateData('tb_fasilitas', $data, 'id_fasilitas', $id);
        $pesan = array('Data <b> Fasilitas </b> berhasil diedit..', 'alert-warning', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Fasilitas', 'refresh');
    }
    public function simpan()
    {
        $gambar = $_FILES['foto']['name'];
        if ($gambar) {
            $alphanum = "abcdefghijklmnopqrstuvwxyz0123456789";
            $nama = str_shuffle($alphanum); //random nama dengan alphanum
            $config['file_name'] = $nama;
            $config['upload_path'] = "assets/img/fasilitas"; // lokasi penyimpanan file
            $config['allowed_types'] = 'gif|jpg|JPEG|png|jpeg|BMP|bmp'; // format foto yang diizinkan 
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            if ($this->upload->do_upload('foto')) {
                $gambar = $this->upload->file_name;
            } else {
                $gambar = 'default.png';
            }
        } else {
            $gambar = 'default.png';
        }

        $data = array(
            'deskripsi' => $this->input->post('deskripsi'),
            'foto' => $gambar,
        );
        $this->Paud_model->simpanData('tb_fasilitas', $data);
        $pesan = array('Data <b> Fasilitas </b> berhasil disimpan..', 'alert-success', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Fasilitas', 'refresh');
        // var_dump($data);
    }
}
