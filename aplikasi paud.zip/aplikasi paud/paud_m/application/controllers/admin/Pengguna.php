<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Pengguna extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $cek = $this->session->userdata('logged_in');
        $status = $this->session->userdata('status');
        if (($cek) && $status == 'admin') {
            $data['judul'] = 'Pengguna';
            $data['content'] = 'admin/viewPengguna';
            $data['pengguna'] = $this->Paud_model->bacaData('tb_login')->result();
            $this->load->view('admin/layout', $data);
        } else {
            header('location:' . base_url('Home'));
        }
    }
    public function hapus($id)
    {
        $this->Paud_model->hapusData('tb_login', 'id_login', $id);
        $pesan = array('Data berhasil dihapus..', 'alert-danger', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Pengguna', 'refresh');
    }
    public function update()
    {
        $id = $this->input->post('id_login');
        $username = $this->input->post('username');
        $data = [
            'username' => $username,
            'telp' => $this->input->post('telp'),
            'status' => $this->input->post('status'),
            'password' => md5($this->input->post('password')),
            'password2' => $this->input->post('password'),
        ];
        $this->Paud_model->updateData('tb_login', $data, 'id_login', $id);
        $pesan = array('Data <b>' . $username . '</b> berhasil diedit..', 'alert-warning', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Pengguna', 'refresh');
    }
    public function simpan()
    {
        $username = $this->input->post('username');
        $data = array(
            'username' => $username,
            'telp' => $this->input->post('telp'),
            'status' => $this->input->post('status'),
            'password' => md5($this->input->post('password')),
            'password2' => $this->input->post('password'),
        );
        $this->Paud_model->simpanData('tb_login', $data);
        $pesan = array('Data <b>' . $username . '</b> berhasil disimpan..', 'alert-success', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Pengguna', 'refresh');
    }
}
