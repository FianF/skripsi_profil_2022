<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $cek = $this->session->userdata('logged_in');
        $status = $this->session->userdata('status');
        if (($cek) && $status == 'admin') {

            $data = [
                'judul' => 'Dashboard',
                'content' => 'admin/viewHome',
                'siswa' => $this->Paud_model->bacaData('tb_siswa')->num_rows(),
                'guru' => $this->Paud_model->bacaData('tb_guru')->num_rows(),
                'pendaftaran' => $this->Paud_model->bacaData('tb_pendaftaran')->num_rows(),
            ];
            $this->load->view('admin/layout', $data);
        } else {
            header('location:' . base_url('Home'));
        }
    }
}
