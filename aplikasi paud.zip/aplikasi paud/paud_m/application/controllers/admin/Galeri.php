<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Galeri extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $cek = $this->session->userdata('logged_in');
        $status = $this->session->userdata('status');
        if (($cek) && $status == 'admin') {
            $data['judul'] = 'Galeri';
            $data['content'] = 'admin/viewGaleri';
            $data['galeri'] = $this->Paud_model->bacaData('tb_galeri')->result();
            $this->load->view('admin/layout', $data);
        } else {
            header('location:' . base_url('Home'));
        }
    }

    public function hapus($id)
    {
        $this->Paud_model->hapusData('tb_galeri', 'id_galeri', $id);
        $pesan = array('Data berhasil dihapus..', 'alert-danger', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Galeri', 'refresh');
    }
    public function update()
    {
        $x = 1;
        $gambar = $_FILES['gambar']['name'];
        if ($gambar) {
            $alphanum = "abcdefghijklmnopqrstuvwxyz0123456789";
            $nama = str_shuffle($alphanum); //random nama dengan alphanum
            $config['file_name'] = $nama;
            $config['upload_path'] = "assets/img/galeri"; // lokasi penyimpanan file
            $config['allowed_types'] = 'gif|jpg|JPEG|png|jpeg|BMP|bmp'; // format foto yang diizinkan 
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            if ($this->upload->do_upload('gambar')) {
                $gambar = $this->upload->file_name;
                $x = 0;
            }
        }

        $id = $this->input->post('id_galeri');
        $nama = "galeri";
        if ($x == 0) {
            $data['gambar'] = $gambar;
        }

        $this->Paud_model->updateData('tb_galeri', $data, 'id_galeri', $id);
        $pesan = array('Data <b>' . $nama . '</b> berhasil diedit..', 'alert-warning', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Galeri', 'refresh');
    }
    public function simpan()
    {
        $gambar = $_FILES['gambar']['name'];
        if ($gambar) {
            $alphanum = "abcdefghijklmnopqrstuvwxyz0123456789";
            $nama = str_shuffle($alphanum); //random nama dengan alphanum
            $config['file_name'] = $nama;
            $config['upload_path'] = "assets/img/galeri"; // lokasi penyimpanan file
            $config['allowed_types'] = 'gif|jpg|JPEG|png|jpeg|BMP|bmp'; // format gambar yang diizinkan 
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            if ($this->upload->do_upload('gambar')) {
                $gambar = $this->upload->file_name;
            } else {
                $gambar = 'default-gambar.png';
            }
        } else {
            $gambar = 'default-gambar.png';
        }

        $nama = "galeri";
        $data = array('gambar' => $gambar);
        $this->Paud_model->simpanData('tb_galeri', $data);
        $pesan = array('Data <b>' . $nama . '</b> berhasil disimpan..', 'alert-success', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Galeri', 'refresh');
        // var_dump($data);
    }
}
