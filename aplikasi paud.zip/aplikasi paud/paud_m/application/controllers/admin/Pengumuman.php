<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Pengumuman extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $cek = $this->session->userdata('logged_in');
        $status = $this->session->userdata('status');
        if (($cek) && $status == 'admin') {
            $data['judul'] = 'Pengumuman';
            $data['content'] = 'admin/viewPengumuman';
            $data['pengumuman'] = $this->Paud_model->bacaData('tb_pengumuman')->result();
            $this->load->view('admin/layout', $data);
        } else {
            header('location:' . base_url('Home'));
        }
    }

    public function hapus($id)
    {
        $this->Paud_model->hapusData('tb_pengumuman', 'id_pengumuman', $id);
        $pesan = array('Data berhasil dihapus..', 'alert-danger', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Pengumuman');
    }
    public function update()
    {
        $id = $this->input->post('id_pengumuman');
        $judul = $this->input->post('judul');
        $data = [
            'judul' => $judul,
            'isi' => $this->input->post('isi'),
            'tanggal' => date("Y/m/d"),
        ];
        $this->Paud_model->updateData('tb_pengumuman', $data, 'id_pengumuman', $id);
        $pesan = array('Data <b>' . $judul . '</b> berhasil diedit..', 'alert-warning', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Pengumuman');
    }
    public function simpan()
    {
        $judul = $this->input->post('judul');
        $data = array(
            'judul' => $judul,
            'isi' => $this->input->post('isi'),
            'tanggal' => date("Y/m/d"),
        );
        $this->Paud_model->simpanData('tb_pengumuman', $data);
        $pesan = array('Data <b>' . $judul . '</b> berhasil disimpan..', 'alert-success', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Pengumuman');
    }
}
