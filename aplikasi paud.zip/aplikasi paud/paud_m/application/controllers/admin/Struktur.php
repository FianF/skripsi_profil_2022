<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Struktur extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $cek = $this->session->userdata('logged_in');
        $status = $this->session->userdata('status');
        if (($cek) && $status == 'admin') {
            $data['judul'] = 'Struktur Organisasi';
            $data['content'] = 'admin/viewStruktur';
            $data['struktur'] = $this->Paud_model->bacaData('tb_struktur')->result();
            $this->load->view('admin/layout', $data);
        } else {
            header('location:' . base_url('Home'));
        }
    }

    public function hapus($id)
    {
        $this->Paud_model->hapusData('tb_struktur', 'id_struktur', $id);
        $pesan = array('Data berhasil dihapus..', 'alert-danger', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Struktur');
    }
    public function update()
    {
        $x = 1;
        $gambar = $_FILES['foto']['name'];
        if ($gambar) {
            $alphanum = "abcdefghijklmnopqrstuvwxyz0123456789";
            $nama = str_shuffle($alphanum); //random nama dengan alphanum
            $config['file_name'] = $nama;
            $config['upload_path'] = "assets/img/struktur"; // lokasi penyimpanan file
            $config['allowed_types'] = 'gif|jpg|JPEG|png|JPEG|BMP|bmp'; // format foto yang diizinkan 
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            if ($this->upload->do_upload('foto')) {
                $gambar = $this->upload->file_name;
                $x = 0;
            }
        }

        $id = $this->input->post('id_struktur');
        $nama = $this->input->post('nama');
        $data = [
            'nama' => $nama,
            'jabatan' => $this->input->post('jabatan'),
        ];
        if ($x == 0) {
            $data['foto'] = $gambar;
        }
        $this->Paud_model->updateData('tb_struktur', $data, 'id_struktur', $id);
        $pesan = array('Data <b>' . $nama . '</b> berhasil diedit..', 'alert-warning', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Struktur');
    }
    public function simpan()
    {
        $gambar = $_FILES['foto']['name'];
        if ($gambar) {
            $alphanum = "abcdefghijklmnopqrstuvwxyz0123456789";
            $nama = str_shuffle($alphanum); //random nama dengan alphanum
            $config['file_name'] = $nama;
            $config['upload_path'] = "assets/img/struktur"; // lokasi penyimpanan file
            $config['allowed_types'] = 'gif|jpg|JPEG|png|JPEG|BMP|bmp'; // format foto yang diizinkan 
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            if ($this->upload->do_upload('foto')) {
                $gambar = $this->upload->file_name;
            } else {
                $gambar = 'default.png';
            }
        } else {
            $gambar = 'default.png';
        }

        $nama = $this->input->post('nama');
        $data = array(
            'nama' => $nama,
            'jabatan' => $this->input->post('jabatan'),
            'foto' => $gambar,
        );
        $this->Paud_model->simpanData('tb_struktur', $data);
        $pesan = array('Data <b>' . $nama . '</b> berhasil disimpan..', 'alert-success', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Struktur');
    }
}
