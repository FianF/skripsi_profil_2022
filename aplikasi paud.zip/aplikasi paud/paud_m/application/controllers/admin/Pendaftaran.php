<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Pendaftaran extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $cek = $this->session->userdata('logged_in');
        $status = $this->session->userdata('status');
        if (($cek) && $status == 'admin') {
            $data['judul'] = 'Pendaftaran';
            $data['content'] = 'admin/viewPendaftaran';
            $data['pendaftaran'] = $this->Paud_model->bacaData('tb_pendaftaran')->result();
            $this->load->view('admin/layout', $data);
        } else {
            header('location:' . base_url('Home'));
        }
    }
    public function hapus($id)
    {
        $this->Paud_model->hapusData('tb_pendaftaran', 'id_pendaftaran', $id);
        $pesan = array('Data berhasil dihapus..', 'alert-danger', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Pendaftaran', 'refresh');
    }
    public function update()
    {
        $id = $this->input->post('id_pendaftaran');
        $nama = $this->input->post('nama');
        $data = array(
            'nama' => $nama,
            'jk' => $this->input->post('jk'),
            'ttl' => $this->input->post('ttl'),
            'alamat' => $this->input->post('alamat'),
            'agama' => $this->input->post('agama'),
            'ortu' => $this->input->post('ortu'),
            'telp' => $this->input->post('telp'),
            'tanggal' => date("Y/m/d"),
        );
        $this->Paud_model->updateData('tb_pendaftaran', $data, 'id_pendaftaran', $id);
        $pesan = array('Data <b>' . $nama . '</b> berhasil diedit..', 'alert-warning', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Pendaftaran', 'refresh');
    }
    public function simpan()
    {
        $nama = $this->input->post('nama');
        $data = array(
            'nama' => $nama,
            'jk' => $this->input->post('jk'),
            'ttl' => $this->input->post('ttl'),
            'alamat' => $this->input->post('alamat'),
            'agama' => $this->input->post('agama'),
            'ortu' => $this->input->post('ortu'),
            'telp' => $this->input->post('telp'),
            'tanggal' => date("Y/m/d"),
        );
        $this->Paud_model->simpanData('tb_pendaftaran', $data);
        $pesan = array('Data <b>' . $nama . '</b> berhasil disimpan..', 'alert-success', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Pendaftaran', 'refresh');
    }
    public function daftarUser()
    {
        $data = array(
            'nama' => $this->input->post('nama'),
            'jk' => $this->input->post('jk'),
            'ttl' => $this->input->post('ttl'),
            'alamat' => $this->input->post('alamat'),
            'agama' => $this->input->post('agama'),
            'ortu' => $this->input->post('ortu'),
            'telp' => $this->input->post('telp'),
            'tanggal' => date("Y/m/d"),
        );
        $this->Paud_model->simpanData('tb_pendaftaran', $data);

?>
        <script>
            alert('Anda berhasil daftar..!!!');
            location.href = '<?= base_url("Home"); ?>';
        </script>
<?php
    }

    public function cetak()
    {
        $tanggalMulai = $this->input->post('tanggalMulai');
        $tanggalSelesai = $this->input->post('tanggalSelesai');
        $data['cetakPendaftaran'] = $this->Paud_model->cetakPendaftaran($tanggalMulai, $tanggalSelesai);
        // var_dump($cetakPendaftaran);
        return $this->load->view('admin/cetak/cetakPendaftaran', $data);
    }
}
