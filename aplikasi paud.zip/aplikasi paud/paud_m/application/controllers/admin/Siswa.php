<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Siswa extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $cek = $this->session->userdata('logged_in');
        $status = $this->session->userdata('status');
        if (($cek) && $status == 'admin') {
            $data['judul'] = 'Siswa';
            $data['content'] = 'admin/viewSiswa';
            $data['siswa'] = $this->Paud_model->bacaData('tb_siswa')->result();
            $this->load->view('admin/layout', $data);
        } else {
            header('location:' . base_url('Home'));
        }
    }

    public function hapus($id)
    {
        $this->Paud_model->hapusData('tb_siswa', 'id_siswa', $id);
        $pesan = array('Data berhasil dihapus..', 'alert-danger', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Siswa', 'refresh');
    }
    public function update()
    {
        $x = 1;
        $gambar = $_FILES['foto']['name'];
        if ($gambar) {
            $alphanum = "abcdefghijklmnopqrstuvwxyz0123456789";
            $nama = str_shuffle($alphanum); //random nama dengan alphanum
            $config['file_name'] = $nama;
            $config['upload_path'] = "assets/img/siswa"; // lokasi penyimpanan file
            $config['allowed_types'] = 'gif|jpg|jpeg|png|JPEG|BMP|bmp'; // format foto yang diizinkan 
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            if ($this->upload->do_upload('foto')) {
                $gambar = $this->upload->file_name;
                $x = 0;
            }
        }

        $id = $this->input->post('id_siswa');
        $nama = $this->input->post('nama');
        $data['nama'] = $nama;
        $data['alamat'] = $this->input->post('alamat');
        $data['kelas'] = $this->input->post('kelas');
        if ($x == 0) {
            $data['foto'] = $gambar;
        }

        $this->Paud_model->updateData('tb_siswa', $data, 'id_siswa', $id);
        $pesan = array('Data <b>' . $nama . '</b> berhasil diedit..', 'alert-warning', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Siswa', 'refresh');
    }
    public function simpan()
    {
        $gambar = $_FILES['foto']['name'];
        if ($gambar) {
            $alphanum = "abcdefghijklmnopqrstuvwxyz0123456789";
            $nama = str_shuffle($alphanum); //random nama dengan alphanum
            $config['file_name'] = $nama;
            $config['upload_path'] = "assets/img/siswa"; // lokasi penyimpanan file
            $config['allowed_types'] = 'gif|jpg|JPEG|png|jpeg|BMP|bmp'; // format foto yang diizinkan 
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            if ($this->upload->do_upload('foto')) {
                $gambar = $this->upload->file_name;
            } else {
                $gambar = 'default.png';
            }
        } else {
            $gambar = 'default.png';
        }

        $nama = $this->input->post('nama');
        $data = array(
            'nama' => $nama,
            'alamat' => $this->input->post('alamat'),
            'kelas' => $this->input->post('kelas'),
            'foto' => $gambar,
        );
        $this->Paud_model->simpanData('tb_siswa', $data);
        $pesan = array('Data <b>' . $nama . '</b> berhasil disimpan..', 'alert-success', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Siswa', 'refresh');
        // var_dump($data);
    }

    public function cetak()
    {
        $kelas = $this->input->post('kelas');
        $data['cetakSiswa'] = $this->Paud_model->cetakKelas($kelas);
        // var_dump($cetakKelas);
        return $this->load->view('admin/cetak/cetakSiswa', $data);
    }
}
