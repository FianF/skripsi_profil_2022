<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Profil extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        $cek = $this->session->userdata('logged_in');
        $status = $this->session->userdata('status');
        if (($cek) && $status == 'admin') {
            $data['judul'] = 'Visi Misi';
            $data['content'] = 'admin/viewVisiMisi';
            $data['visiMisi'] = $this->Paud_model->bacaData('tb_profil')->result_array();
            $this->load->view('admin/layout', $data);
        } else {
            header('location:' . base_url('Home'));
        }
    }
    public function updateVisiMisi()
    {

        $visi['isi'] = $this->input->post('visi');
        $this->Paud_model->updateData('tb_profil', $visi, 'id_profil', 2);
        $misi['isi'] = $this->input->post('misi');
        $this->Paud_model->updateData('tb_profil', $misi, 'id_profil', 3);

        $pesan = array('Data <b>' . 'Visi Misi' . '</b> berhasil diedit..', 'alert-warning', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Profil');
    }
    public function tentang()
    {
        $cek = $this->session->userdata('logged_in');
        $status = $this->session->userdata('status');
        if (($cek) && $status == 'admin') {
            $data['judul'] = 'Tentang Kami';
            $data['content'] = 'admin/viewTentang';
            $data['tentang'] = $this->Paud_model->bacaData('tb_profil')->result_array();
            $this->load->view('admin/layout', $data);
        } else {
            header('location:' . base_url('Home'));
        }
    }
    public function updateTentang()
    {
        $tentang['isi'] = $this->input->post('tentang');
        $this->Paud_model->updateData('tb_profil', $tentang, 'id_profil', 1);

        $pesan = array('Data <b>' . 'Tentang' . '</b> berhasil diedit..', 'alert-warning', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Profil/tentang');
    }
    public function kontak()
    {
        $cek = $this->session->userdata('logged_in');
        $status = $this->session->userdata('status');
        if (($cek) && $status == 'admin') {
            $data['judul'] = 'Kontak';
            $data['content'] = 'admin/viewKontak';
            $data['kontak'] = $this->Paud_model->bacaData('tb_profil')->result_array();
            $this->load->view('admin/layout', $data);
        } else {
            header('location:' . base_url('Home'));
        }
    }
    public function updateKontak()
    {
        $telp['isi'] = $this->input->post('telp');
        $this->Paud_model->updateData('tb_profil', $telp, 'id_profil', 4);
        $email['isi'] = $this->input->post('email');
        $this->Paud_model->updateData('tb_profil', $email, 'id_profil', 5);

        $pesan = array('Data <b>' . 'Tentang' . '</b> berhasil diedit..', 'alert-warning', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Profil/kontak');
    }


    public function simpan()
    {
        $judul = $this->input->post('judul');
        $data = array(
            'judul' => $judul,
            'isi' => $this->input->post('isi'),
            'tanggal' => date("Y/m/d"),
        );
        $this->Paud_model->simpanData('tb_profil', $data);
        $pesan = array('Data <b>' . $judul . '</b> berhasil disimpan..', 'alert-success', 'fa-check');
        $this->session->set_flashdata("pesan", $pesan);
        redirect('admin/Pengumuman');
    }
}
