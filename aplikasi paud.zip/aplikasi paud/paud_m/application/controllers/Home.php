<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller
{


    public function _construct()
    {
        session_start();
        parent::__construct();
    }

    public function index()
    {
        $data = [
            'judul' => 'Home',
            'content' => 'globalHome',
            'galeri' => $this->Paud_model->bacaData('tb_galeri')->result(),
            'berita' => $this->Paud_model->bacaData('tb_berita')->result(),
        ];
        $this->load->view('globalLayout', $data);
    }

    public function login()
    {
        $this->load->view('login');
    }
    public function reg()
    {
        $this->load->view('registrasi');
    }
    public function prosesLogin()
    {
        $username = $this->input->post('username');
        $pass = md5($this->input->post('password'));
        $cek_login = $this->Paud_model->cekLogin($username, $pass);
        if ($cek_login) {
            if ($cek_login['status'] == 'admin') {
                // echo "cek";
                $sess_data['logged_in'] = 'yes';
                $sess_data['status'] = 'admin';
                $sess_data['username'] = $username;
                $this->session->set_userdata($sess_data);
                header('location:' . base_url('admin/Home'));
            } else if ($cek_login['status'] == 'user') {
                $sess_data['logged_in'] = 'yes';
                $sess_data['status'] = 'user';
                $sess_data['username'] = $username;
                $this->session->set_userdata($sess_data);
                redirect('Home/pendaftaranSiswa', 'refresh');
            }
        } else {
            redirect('Home/login', 'refresh');
            // header('location:' . base_url('login'));
        }
    }
    public function pendaftaranSiswa()
    {
        $this->load->view('pendaftaranSiswa');
    }
    public function logout()
    {
        $cek = $this->session->userdata('logged_in');
        if (empty($cek)) {
            header('location:' . base_url() . 'Home');
        } else {
            $this->session->sess_destroy();
            header('location:' . base_url() . 'Home');
        }
    }
    public function prosesReg()
    {
        // var_dump('ok');
        $pass2 = $this->input->post('password2');
        $this->form_validation->set_rules('password', 'password', "in_list[$pass2]");

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata("pesan", ['alert-danger', 'Password dan konfirmasi password harus sama !', 'fa-times']);
            redirect('Home/reg', 'refresh');
        } else {
            $data = array(
                'username' => $this->input->post('username'),
                'telp' => $this->input->post('telp'),
                'status' => 'user',
                'password' => md5($this->input->post('password')),
                'password2' => $pass2,
            );
            $this->Paud_model->simpanData('tb_login', $data);
            $this->session->set_flashdata("pesan", ['alert-success', 'Anda berhasil daftar..', 'fa-check-square-o']);
            redirect("Home/login", "refresh");
        }
    }

    public function guru()
    {
        $data = [
            'judul' => 'Guru',
            'guru' => $this->Paud_model->bacaData('tb_guru')->result(),
            'content' => 'globalGuru'
        ];
        $this->load->view('globalLayout', $data);
    }
    public function siswa()
    {
        $data = [
            'judul' => 'Siswa',
            'siswa' => $this->Paud_model->bacaData('tb_siswa')->result(),
            'content' => 'globalSiswa'
        ];
        $this->load->view('globalLayout', $data);
    }
    public function pengumuman()
    {
        $data = [
            'judul' => 'Pengumuman',
            'pengumuman' => $this->Paud_model->bacaData('tb_pengumuman')->result(),
            'content' => 'globalPengumuman'
        ];
        $this->load->view('globalLayout', $data);
    }
    public function tentang()
    {
        $data = [
            'judul' => 'Tentang',
            'tentang' => $this->Paud_model->bacaData('tb_profil')->result_array(),
            'content' => 'globalTentang'
        ];
        $this->load->view('globalLayout', $data);
    }
    public function visiMisi()
    {
        $data = [
            'judul' => 'Visi Misi',
            'visiMisi' => $this->Paud_model->bacaData('tb_profil')->result_array(),
            'content' => 'globalVisiMisi'
        ];
        $this->load->view('globalLayout', $data);
    }
    public function struktur()
    {
        $data = [
            'judul' => 'Struktur',
            'struktur' => $this->Paud_model->bacaData('tb_struktur')->result(),
            'content' => 'globalStruktur'
        ];
        $this->load->view('globalLayout', $data);
    }
    public function galeri()
    {
        $data = [
            'judul' => 'Galeri',
            'galeri' => $this->Paud_model->bacaData('tb_galeri')->result(),
            'content' => 'globalGaleri'
        ];
        $this->load->view('globalLayout', $data);
    }
    public function fasilitas()
    {
        $data = [
            'judul' => 'Fasilitas',
            'fasilitas' => $this->Paud_model->bacaData('tb_fasilitas')->result(),
            'content' => 'globalFasilitas'
        ];
        $this->load->view('globalLayout', $data);
    }
    public function kontak()
    {
        $data = [
            'judul' => 'Kontak',
            'kontak' => $this->Paud_model->bacaData('tb_profil')->result_array(),
            'content' => 'globalKontak'
        ];
        $this->load->view('globalLayout', $data);
    }

    public function detail_berita($id)
    {
        // echo 'ini home/detail berita' . $id;
        $data = [
            'judul' => 'Home',
            'content' => 'globalBerita',
            'galeri' => $this->Paud_model->bacaData('tb_galeri')->result(),
            'berita' => $this->Paud_model->editData('tb_berita', 'id_berita', $id),
        ];
        $this->load->view('globalLayout', $data);
    }
}
